﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using XDevkitPlusPlus;
using XRPCLib;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        XRPC XRPC = new XRPC();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XRPC.Connect();
            if (XRPC.activeConnection == true)
            {
                MessageBox.Show("Connection Successful!");
            }

            else
            {
                MessageBox.Show("Connection Failed!");
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                byte[] Krauser = {0x39, 0x60, 0x00, 0x00};
                XRPC.SetMemory(0x824C6608, Krauser);
            }

            else
            {
                byte[] Krauser = {0x35, 0x6B, 0xFF, 0xFF};
                XRPC.SetMemory(0x824C6608, Krauser);
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                byte[] GunAmmo = { 0x60, 0x00, 0x00, 0x00 };
                byte[] GrenadeAmmo = { 0x39, 0x60, 0x00, 0xFF };
                byte[] HerbAmmo = { 0x39, 0x40, 0x00, 0xFF };
                XRPC.SetMemory(0x8232FFFC, GunAmmo);
                XRPC.SetMemory(0x8232F670, GrenadeAmmo);
                XRPC.SetMemory(0x8232DC44, HerbAmmo);
                XRPC.SetMemory(0x8232FEB8, GrenadeAmmo); //This actually sets bow ammo, but both used the same bytes.
            }

            else
            {
                byte[] GunAmmo = { 0xB1, 0x5E, 0x00, 0x08 };
                byte[] GrenadeAmmo = { 0x39, 0x6B, 0xFF, 0xFF };
                byte[] HerbAmmo = { 0x39, 0x4A, 0xFF, 0xFF };
                XRPC.SetMemory(0x8232FFFC, GunAmmo);
                XRPC.SetMemory(0x8232F670, GrenadeAmmo);
                XRPC.SetMemory(0x8232DC44, HerbAmmo);
                XRPC.SetMemory(0x8232FEB8, GrenadeAmmo); //This actually sets bow ammo, but both used the same bytes.
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            byte[] ShopItem = {0x4B, 0xC6, 0x64, 0xC0};
            byte[] ItemModifierCode = {0x3B, 0x60, 0x00, 0x00, 0xB3, 0x7E, 0x00, 0x10, 0x48, 0x39, 0x9B, 0x3C};
            XRPC.SetMemory(0x82399B5C, ShopItem);
            XRPC.SetMemory(0x8200001C, ItemModifierCode);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte[] ShopItem = {0xB3, 0x7E, 0x00, 0x10};
            XRPC.SetMemory(0x82399B5C, ShopItem);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To properly use the tool, click Connect. If you want to get any item in the game, click the Enable Shop Modifier button and select the item you want from the drop-down menu. Then, buy it in-game. I recommend using this with the Infinite Money cheat at the same time. If you want items in the shop to return to normal, click Disable Shop Modifier");
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                byte[] ID = {0x0};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                byte[] ID = {0x1};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                byte[] ID = {0x2};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                byte[] ID = {0x3};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                byte[] ID = {0x4};
                XRPC.SetMemory(0x8200001F, ID);
            }

            else if (comboBox1.SelectedIndex == 5)
            {
                byte[] ID = {0x5};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 6)
            {
                byte[] ID = {0x6};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 7)
            {
                byte[] ID = {0x7};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 8)
            {
                byte[] ID = {0x8};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 9)
            {
                byte[] ID = {0x9};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 10)
            {
                byte[] ID = {0xA};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 11)
            {
                byte[] ID = {0xC};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 12)
            {
                byte[] ID = {0xE};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 13)
            {
                byte[] ID = {0x12};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 14)
            {
                byte[] ID = {0x13};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 15)
            {
                byte[] ID = {0x14};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 16)
            {
                byte[] ID = {0x15};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 17)
            {
                byte[] ID = {0x16};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 18)
            {
                byte[] ID = {0x17};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 19)
            {
                byte[] ID = {0x18};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 20)
            {
                byte[] ID = {0x19};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 21)
            {
                byte[] ID = {0x1A};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 22)
            {
                byte[] ID = {0x1B};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 23)
            {
                byte[] ID = {0x1C};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 24)
            {
                byte[] ID = {0x20};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 25)
            {
                byte[] ID = {0x21};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 26)
            {
                byte[] ID = {0x23};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 27)
            {
                byte[] ID = {0x25};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 28)
            {
                byte[] ID = {0x27};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 29)
            {
                byte[] ID = {0x29};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 30)
            {
                byte[] ID = {0x2A};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 31)
            {
                byte[] ID = {0x2C};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 32)
            {
                byte[] ID = {0x2D};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 33)
            {
                byte[] ID = {0x2E};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 34)
            {
                byte[] ID = {0x2F};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 35)
            {
                byte[] ID = {0x30};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 36)
            {
                byte[] ID = {0x34};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 37)
            {
                byte[] ID = {0x35};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 38)
            {
                byte[] ID = {0x36};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 39)
            {
                byte[] ID = {0x37};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 40)
            {
                byte[] ID = {0x38};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 41)
            {
                byte[] ID = {0x3E};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 42)
            {
                byte[] ID = {0x3F};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 43)
            {
                byte[] ID = {0x40};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 44)
            {
                byte[] ID = {0x41};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 45)
            {
                byte[] ID = {0x42};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 46)
            {
                byte[] ID = {0x43};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 47)
            {
                byte[] ID = {0x44};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 48)
            {
                byte[] ID = {0x45};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 49)
            {
                byte[] ID = {0x46};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 50)
            {
                byte[] ID = {0x47};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 51)
            {
                byte[] ID = {0x52};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 52)
            {
                byte[] ID = {0x54};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 53)
            {
                byte[] ID = {0x55};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 54)
            {
                byte[] ID = {0x6A};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 55)
            {
                byte[] ID = {0x6D};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 56)
            {
                byte[] ID = {0x72};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 57)
            {
                byte[] ID = {0x7D};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 58)
            {
                byte[] ID = {0x7E};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 59)
            {
                byte[] ID = {0x7F};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 60)
            {
                byte[] ID = {0x94};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 61)
            {
                byte[] ID = {0x95};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 62)
            {
                byte[] ID = {0x97};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 63)
            {
                byte[] ID = {0xA8};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 64)
            {
                byte[] ID = {0xA9};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 65)
            {
                byte[] ID = {0xAA};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 66)
            {
                byte[] ID = {0xC5};
                XRPC.SetMemory(0x8200001F, ID);
            }
            else if (comboBox1.SelectedIndex == 67)
            {
                byte[] ID = {0xFE};
                XRPC.SetMemory(0x8200001F, ID);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This tool is a tool I'll use for the fun of it. It should work in every game mode. Thank you Lord for giving me the knowledge to make this tool! Thank you MODDED WARFARE and MBRKiNG for the tutorial videos on how to make trainers, too!");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                byte[] Money = {0x7F, 0xFF, 0xFF, 0xFF};
                XRPC.SetMemory(0xC265D848, Money);
            }

            else
            {
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                byte[] HP = {0x09, 0x60, 0x09, 0x60};
                XRPC.SetMemory(0xC265D854, HP);
                byte[] HPAshley = {0x7E, 0x90, 0x7E, 0x90};
                XRPC.SetMemory(0xC265D858, HPAshley);
            }

            else
            {
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                byte[] Character = {0x0};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 1)
            {
                byte[] Character = {0x0, 0x2};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 2)
            {
                byte[] Character = {0x0, 0x3};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 3)
            {
                byte[] Character = {0x0, 0x4};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 4)
            {
                byte[] Character = {0x0, 0x5};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 5)
            {
                byte[] Character = {0x1};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 6)
            {
                byte[] Character = {0x2};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 7)
            {
                byte[] Character = {0x2, 0x3};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 8)
            {
                byte[] Character = {0x3};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 9)
            {
                byte[] Character = {0x4};
                XRPC.SetMemory(0xC265D868, Character);
            }

            else if (comboBox2.SelectedIndex == 10)
            {
                byte[] Character = {0x5};
                XRPC.SetMemory(0xC265D868, Character);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To properly switch to another character, first you must save with a weapon your character is able to use. Then reload from your current save. Otherwise, the game will crash. Here are the following glitches that will happen while using modded characters: \nAll characters except Leon crash if you go into the inventory, upon loading into a chapter (this might make the save unusable), and upon radio transmissions. \nAll characters except Leon may not be able to finish each stage properly due to them lacking the proper animations (like jumping over a bridge). \nCharacters may cause crashes at random. \nWesker and HUNK crashes on using the merchant and melee moves.");
        }
    }
}
