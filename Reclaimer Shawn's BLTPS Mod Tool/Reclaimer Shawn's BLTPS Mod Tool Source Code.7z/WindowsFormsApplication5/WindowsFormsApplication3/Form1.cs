﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using XDevkitPlusPlus;
using XRPCLib;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        XRPC XRPC = new XRPC();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            XRPC.Connect();
            if (XRPC.activeConnection == true)
            {
                MessageBox.Show("Connection Successful!");
            }

            else
            {
                MessageBox.Show("Connection Failed!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) When using Infinite BAR Tokens, keep the option checked while in the BAR menu and uncheck it after you leave the BAR menu to avoid glitches. \n2) Insta-Kill causes all enemies that spawn or are currently spawned to die immediately. My advice is to not enable this until you want certain enemies dead. If you enable it the whole time, enemies die before they even spawn, making Pandora a very lonely place. \n3) While Infinite Vehicle Boost is enabled, vehicles shake for some reason. I have no idea why, but it doesn't negatively affect the game. \n4) This tool might be able to edit online savegames, assuming you're host.");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                byte[] Money1 = {0x3C, 0x60, 0x7F, 0xFF};
                byte[] Money2 = {0x3D, 0x60, 0x7F, 0xFF};
                XRPC.SetMemory(0x82E9F3D0, Money1);
                XRPC.SetMemory(0x82E9F4C0, Money2);
            }

            else
            {
                byte[] Money1 = {0x80, 0x6A, 0x02, 0xAC};
                byte[] Money2 = {0x81, 0x6A, 0x02, 0xAC};
                XRPC.SetMemory(0x82E9F3D0, Money1);
                XRPC.SetMemory(0x82E9F4C0, Money2);
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                byte[] SkillPoints = {0x91, 0x29, 0x02, 0x80};
                XRPC.SetMemory(0x82C79DD0, SkillPoints);
            }

            else
            {
                byte[] SkillPoints = {0x81, 0x69, 0x02, 0x80};
                XRPC.SetMemory(0x82C79DD0, SkillPoints);
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                byte[] SkillCooldown = {0x90, 0x0A, 0x00, 0x6C};
                XRPC.SetMemory(0x82C9D9C8, SkillCooldown);
            }

            else
            {
                byte[] SkillCooldown = {0xC3, 0xEA, 0x00, 0x6C};
                XRPC.SetMemory(0x82C9D9C8, SkillCooldown);
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                byte[] BranchToCave = {0x4B, 0x3C, 0x89, 0x40};
                byte[] CodeCave = {0x3C, 0xA0, 0x7F, 0xFF, 0x60, 0xA5, 0xFF, 0xC8, 0x90, 0xAB, 0x02, 0x58, 0x48, 0xC3, 0x76, 0xB8};
                XRPC.SetMemory(0x82C9FF3C, BranchToCave);
                XRPC.SetMemory(0x8206887C, CodeCave);
            }

            else
            {
                byte[] BranchToCave = {0x80, 0xAB, 0x02, 0x58};
                XRPC.SetMemory(0x82C9FF3C, BranchToCave);
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                byte[] JumpToGrenadeCodeCave = {0x4B, 0x3C, 0x8F, 0xD0};
                byte[] GrenadeCodeCave = {0xC0, 0x0B, 0x00, 0x6C, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x3F, 0xE0, 0x4F, 0x00, 0x93, 0xEB, 0x00, 0x6C, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x48, 0xC3, 0x70, 0x18};
                byte[] OZ = {0xD1, 0x9F, 0x00, 0x6C};
                byte[] JumpToGunCodeCave = {0x4B, 0x28, 0x1B, 0x48};
                byte[] GunCodeCave = {0xC0, 0x05, 0x00, 0x6C, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x3F, 0xE0, 0x4F, 0x00, 0x93, 0xE5, 0x00, 0x6C, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x48, 0xD7, 0xE4, 0xA0};
                XRPC.SetMemory(0x82C9F88C, JumpToGrenadeCodeCave);
                XRPC.SetMemory(0x8206885C, GrenadeCodeCave);
                XRPC.SetMemory(0x82BCA494, OZ);
                XRPC.SetMemory(0x82DE6CF4, JumpToGunCodeCave);
                XRPC.SetMemory(0x8206883C, GunCodeCave);
            }

            else
            {
                byte[] JumpToGrenadeCodeCave = {0xC0, 0x0B, 0x00, 0x6C};
                byte[] OZ = {0xED, 0x9E, 0x68, 0x28};
                byte[] JumpToGunCodeCave = {0xC0, 0x05, 0x00, 0x6C};
                XRPC.SetMemory(0x82C9F88C, JumpToGrenadeCodeCave);
                XRPC.SetMemory(0x82BCA494, OZ);
                XRPC.SetMemory(0x82DE6CF4, JumpToGunCodeCave);
            }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                byte[] JumpToCodeCave = {0xC1, 0xA6, 0x00, 0x6C};
                XRPC.SetMemory(0x827083CC, JumpToCodeCave);
            }

            else if (comboBox2.SelectedIndex == 1)
            {
                byte[] JumpToCodeCave = {0x4B, 0x96, 0x03, 0xB4};
                byte[] CodeCave = {0xC1, 0xA6, 0x00, 0x6C, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x83, 0xE6, 0x00, 0x60, 0x2C, 0x1F, 0x00, 0x00, 0x41, 0x82, 0x00, 0x10, 0x60, 0x00, 0x00, 0x00, 0x60, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00, 0x08, 0x93, 0xE6, 0x00, 0x6C, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x48, 0x69, 0xFC, 0x20};
                XRPC.SetMemory(0x82068780, CodeCave);
                XRPC.SetMemory(0x827083CC, JumpToCodeCave);
            }

            else if (comboBox2.SelectedIndex == 2)
            {
                byte[] JumpToCodeCave = {0x4B, 0x96, 0x03, 0xB4};
                byte[] CodeCave = {0xC1, 0xA6, 0x00, 0x6C, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x83, 0xE6, 0x00, 0x60, 0x2C, 0x1F, 0x00, 0x00, 0x41, 0x82, 0x00, 0x10, 0x3F, 0xE0, 0x4F, 0x00, 0x93, 0xE6, 0x00, 0x6C, 0x48, 0x00, 0x00, 0x08, 0x60, 0x00, 0x00, 0x00, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x48, 0x69, 0xFC, 0x20};
                XRPC.SetMemory(0x82068780, CodeCave);
                XRPC.SetMemory(0x827083CC, JumpToCodeCave);
            }

            else if (comboBox2.SelectedIndex == 3)
            {
                byte[] JumpToCodeCave = {0x4B, 0x96, 0x03, 0xB4};
                byte[] CodeCave = {0xC1, 0xA6, 0x00, 0x6C, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x83, 0xE6, 0x00, 0x60, 0x2C, 0x1F, 0x00, 0x00, 0x41, 0x82, 0x00, 0x10, 0x3F, 0xE0, 0x4F, 0x00, 0x93, 0xE6, 0x00, 0x6C, 0x48, 0x00, 0x00, 0x08, 0x93, 0xE6, 0x00, 0x6C, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x48, 0x69, 0xFC, 0x20};
                XRPC.SetMemory(0x82068780, CodeCave);
                XRPC.SetMemory(0x827083CC, JumpToCodeCave);
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
            {
                byte[] Boost = {0xD0, 0x1F, 0x00, 0x6C};
                XRPC.SetMemory(0x82CA5B28, Boost);
            }

            else
            {
                byte[] Boost = {0xED, 0xA0, 0xF8, 0x28};
                XRPC.SetMemory(0x82CA5B28, Boost);
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked)
            {
                byte[] BAR = {0x39, 0x20, 0x7F, 0xFF};
                XRPC.SetMemory(0x823A8C7C, BAR);
            }

            else
            {
                byte[] BAR = {0x81, 0x3E, 0x00, 0x00};
                XRPC.SetMemory(0x823A8C7C, BAR);
            }
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked)
            {
                byte[] NOP = {0x60, 0x00, 0x00, 0x00};
                XRPC.SetMemory(0x82E4EFC4, NOP);
                XRPC.SetMemory(0x82E4F014, NOP);
                XRPC.SetMemory(0x82E4F01C, NOP);
                XRPC.SetMemory(0x82E4F030, NOP);
                XRPC.SetMemory(0x82E4F040, NOP);
            }

            else
            {
                byte[] Branch1 = {0x4B, 0x52, 0x10, 0x8D};
                byte[] Branch2 = {0x48, 0x38, 0xE5, 0xAD};
                byte[] Branch3 = {0x4B, 0xE1, 0x4B, 0x95};
                byte[] Branch4 = {0x4B, 0xEA, 0x58, 0x49};
                byte[] Branch5 = {0x4B, 0xE1, 0x4B, 0x71};
                XRPC.SetMemory(0x82E4EFC4, Branch1);
                XRPC.SetMemory(0x82E4F014, Branch2);
                XRPC.SetMemory(0x82E4F01C, Branch3);
                XRPC.SetMemory(0x82E4F030, Branch4);
                XRPC.SetMemory(0x82E4F040, Branch5);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Credits for the tool go to: \nAbove all else, God and his Son Jesus Christ. \nReclaimer Shawn for most of the tool. \nC0dycode of Shadowevil's modding Discord and Ry of Borderlands: Community Hangout for helping me patch out the sanity check.");
        }
    }
}
