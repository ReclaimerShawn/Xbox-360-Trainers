﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using XDevkitPlusPlus;
using XRPCLib;

namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {
        XRPC XRPC = new XRPC();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            XRPC.Connect();
            if (XRPC.activeConnection == true)
            {
                MessageBox.Show("Connection Successful!");
            }

            else
            {
                MessageBox.Show("Connection Failed!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("God the Father and his Son Jesus Christ\nReclaimer Shawn for making the tool\nManuel Pazos 2012 for his save editor tool, which helped me understand how to hack items in\nYecgaa01 for his save, which I tested the tool on and included with the tool");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To use the item editor, first use the included save and load it. Then, open your inventory and enable 'Infinite Ammo'. From here, follow these steps every single time you want to edit your vertical weapons:\n1) Click Enable.\n2) Fire your primary weapon. A table will be listed below with the proper weapon to fire.\n3) If you're Jake or Sherry, check the 'Jake/Sherry' box.\n4) You can now edit the vertical items to set them to whatever you want.\n5) Click Disable. Infinite Ammo will automatically be disabled until you click Disable to prevent crashes. \n6) Reach a checkpoint, then reload your save from the checkpoint. Your items are now replaced with what you wanted. Save whenever you want the effects to be permanent.\nHere is the list of primary weapons:\n \nChris = Assault Rifle for Special Tactis\nPiers = Anti-Material Rifle\nLeon = Wing Shooter\nHelena = Lightning Hawk\nJake = Nine-Oh-Nine (909)\nSherry = Triple Shot\nAda = Crossbow\nCarla = Picador\nAgent = Nine-Oh-Nine (909)");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                checkBox5.Checked = false;
            }

            else
            {

            }

            byte[] CheckAmmo = XRPC.GetMemory(0x830ADDFC, 4);
            Array.Reverse(CheckAmmo);
            uint ResolveCheckAmmo = BitConverter.ToUInt32(CheckAmmo, 0);

            if (ResolveCheckAmmo == 0x4B1B2668)
            {
                byte[] AmmoBranch = {0x7D, 0x2A, 0x1A, 0x2E};
                XRPC.SetMemory(0x830ADDFC, AmmoBranch);
            }

            else
            {

            }

            byte[] ItemCodeCave = {0x7C, 0xEB, 0x1B, 0x2E, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xC1, 0x00, 0x08, 0x7F, 0xEB, 0x1A, 0x14, 0x3B, 0xFF, 0xFF, 0xFC, 0x3F, 0xC0, 0x82, 0x26, 0x93, 0xFE, 0x04, 0x9C, 0x3B, 0xFF, 0x00, 0xE0, 0x93, 0xFE, 0x04, 0xA0, 0x3B, 0xFF, 0x00, 0x1C, 0x93, 0xFE, 0x04, 0xA4, 0x3B, 0xFF, 0x00, 0x1C, 0x93, 0xFE, 0x04, 0xA8, 0x3B, 0xFF, 0x00, 0x38, 0x93, 0xFE, 0x04, 0xAC, 0xBB, 0xC1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x48, 0xE4, 0xDA, 0xA4};
            byte[] Branch = {0x4B, 0x1B, 0x25, 0x1C};
            XRPC.SetMemory(0x82260454, ItemCodeCave);
            XRPC.SetMemory(0x830ADF38, Branch);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte[] Branch = {0x7C, 0xEB, 0x1B, 0x2E};
            XRPC.SetMemory(0x830ADF38, Branch);
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x822604A0, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x0));
            if (comboBox2.SelectedIndex == 0)
            {
                byte[] ID = { 0x1, 0x0 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                byte[] ID = { 0x1, 0x1 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 2)
            {
                byte[] ID = { 0x1, 0x2 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 3)
            {
                byte[] ID = { 0x1, 0x3 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 4)
            {
                byte[] ID = { 0x1, 0x4 };
                XRPC.SetMemory(ResolvePointer, ID);
            }

            else if (comboBox2.SelectedIndex == 5)
            {
                byte[] ID = { 0x1, 0x5 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 6)
            {
                byte[] ID = { 0x1, 0x6 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 7)
            {
                byte[] ID = { 0x1, 0x7 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 8)
            {
                byte[] ID = { 0x1, 0x8 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 9)
            {
                byte[] ID = { 0x1, 0x9 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 10)
            {
                byte[] ID = { 0x1, 0xA };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 11)
            {
                byte[] ID = { 0x1, 0xB };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 12)
            {
                byte[] ID = { 0x1, 0xC };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 13)
            {
                byte[] ID = { 0x1, 0xD };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 14)
            {
                byte[] ID = { 0x1, 0xE };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 15)
            {
                byte[] ID = { 0x1, 0xF };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 16)
            {
                byte[] ID = { 0x1, 0x10 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 17)
            {
                byte[] ID = { 0x1, 0x11 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 18)
            {
                byte[] ID = { 0x1, 0x12 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 19)
            {
                byte[] ID = { 0x1, 0x13 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 20)
            {
                byte[] ID = { 0x1, 0x14 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 21)
            {
                byte[] ID = { 0x1, 0x15 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 22)
            {
                byte[] ID = { 0x1, 0x17 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 23)
            {
                byte[] ID = { 0x1, 0x18 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 24)
            {
                byte[] ID = { 0x1, 0x19 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 25)
            {
                byte[] ID = { 0x1, 0x1A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 26)
            {
                byte[] ID = { 0x1, 0x1B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 27)
            {
                byte[] ID = { 0x1, 0x1C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 28)
            {
                byte[] ID = { 0x1, 0x1D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 29)
            {
                byte[] ID = { 0x1, 0x1E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 30)
            {
                byte[] ID = { 0x1, 0x1F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 31)
            {
                byte[] ID = { 0x1, 0x20 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 32)
            {
                byte[] ID = { 0x1, 0x21 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 33)
            {
                byte[] ID = { 0x1, 0x22 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 34)
            {
                byte[] ID = { 0x1, 0x23 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 35)
            {
                byte[] ID = { 0x1, 0x24 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 36)
            {
                byte[] ID = { 0x1, 0x25 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 37)
            {
                byte[] ID = { 0x1, 0x26 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox2.SelectedIndex == 38)
            {
                byte[] ID = { 0x1, 0x27 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x822604A4, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x0));
            if (comboBox3.SelectedIndex == 0)
            {
                byte[] ID = { 0x1, 0x0 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 1)
            {
                byte[] ID = { 0x1, 0x1 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 2)
            {
                byte[] ID = { 0x1, 0x2 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 3)
            {
                byte[] ID = { 0x1, 0x3 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 4)
            {
                byte[] ID = { 0x1, 0x4 };
                XRPC.SetMemory(ResolvePointer, ID);
            }

            else if (comboBox3.SelectedIndex == 5)
            {
                byte[] ID = { 0x1, 0x5 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 6)
            {
                byte[] ID = { 0x1, 0x6 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 7)
            {
                byte[] ID = { 0x1, 0x7 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 8)
            {
                byte[] ID = { 0x1, 0x8 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 9)
            {
                byte[] ID = { 0x1, 0x9 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 10)
            {
                byte[] ID = { 0x1, 0xA };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 11)
            {
                byte[] ID = { 0x1, 0xB };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 12)
            {
                byte[] ID = { 0x1, 0xC };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 13)
            {
                byte[] ID = { 0x1, 0xD };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 14)
            {
                byte[] ID = { 0x1, 0xE };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 15)
            {
                byte[] ID = { 0x1, 0xF };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 16)
            {
                byte[] ID = { 0x1, 0x10 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 17)
            {
                byte[] ID = { 0x1, 0x11 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 18)
            {
                byte[] ID = { 0x1, 0x12 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 19)
            {
                byte[] ID = { 0x1, 0x13 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 20)
            {
                byte[] ID = { 0x1, 0x14 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 21)
            {
                byte[] ID = { 0x1, 0x15 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 22)
            {
                byte[] ID = { 0x1, 0x17 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 23)
            {
                byte[] ID = { 0x1, 0x18 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 24)
            {
                byte[] ID = { 0x1, 0x19 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 25)
            {
                byte[] ID = { 0x1, 0x1A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 26)
            {
                byte[] ID = { 0x1, 0x1B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 27)
            {
                byte[] ID = { 0x1, 0x1C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 28)
            {
                byte[] ID = { 0x1, 0x1D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 29)
            {
                byte[] ID = { 0x1, 0x1E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 30)
            {
                byte[] ID = { 0x1, 0x1F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 31)
            {
                byte[] ID = { 0x1, 0x20 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 32)
            {
                byte[] ID = { 0x1, 0x21 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 33)
            {
                byte[] ID = { 0x1, 0x22 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 34)
            {
                byte[] ID = { 0x1, 0x23 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 35)
            {
                byte[] ID = { 0x1, 0x24 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 36)
            {
                byte[] ID = { 0x1, 0x25 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 37)
            {
                byte[] ID = { 0x1, 0x26 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox3.SelectedIndex == 38)
            {
                byte[] ID = { 0x1, 0x27 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x822604A8, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x0));
            if (comboBox4.SelectedIndex == 0)
            {
                byte[] ID = { 0x1, 0x0 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 1)
            {
                byte[] ID = { 0x1, 0x1 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 2)
            {
                byte[] ID = { 0x1, 0x2 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 3)
            {
                byte[] ID = { 0x1, 0x3 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 4)
            {
                byte[] ID = { 0x1, 0x4 };
                XRPC.SetMemory(ResolvePointer, ID);
            }

            else if (comboBox4.SelectedIndex == 5)
            {
                byte[] ID = { 0x1, 0x5 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 6)
            {
                byte[] ID = { 0x1, 0x6 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 7)
            {
                byte[] ID = { 0x1, 0x7 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 8)
            {
                byte[] ID = { 0x1, 0x8 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 9)
            {
                byte[] ID = { 0x1, 0x9 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 10)
            {
                byte[] ID = { 0x1, 0xA };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 11)
            {
                byte[] ID = { 0x1, 0xB };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 12)
            {
                byte[] ID = { 0x1, 0xC };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 13)
            {
                byte[] ID = { 0x1, 0xD };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 14)
            {
                byte[] ID = { 0x1, 0xE };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 15)
            {
                byte[] ID = { 0x1, 0xF };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 16)
            {
                byte[] ID = { 0x1, 0x10 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 17)
            {
                byte[] ID = { 0x1, 0x11 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 18)
            {
                byte[] ID = { 0x1, 0x12 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 19)
            {
                byte[] ID = { 0x1, 0x13 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 20)
            {
                byte[] ID = { 0x1, 0x14 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 21)
            {
                byte[] ID = { 0x1, 0x15 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 22)
            {
                byte[] ID = { 0x1, 0x17 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 23)
            {
                byte[] ID = { 0x1, 0x18 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 24)
            {
                byte[] ID = { 0x1, 0x19 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 25)
            {
                byte[] ID = { 0x1, 0x1A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 26)
            {
                byte[] ID = { 0x1, 0x1B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 27)
            {
                byte[] ID = { 0x1, 0x1C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 28)
            {
                byte[] ID = { 0x1, 0x1D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 29)
            {
                byte[] ID = { 0x1, 0x1E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 30)
            {
                byte[] ID = { 0x1, 0x1F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 31)
            {
                byte[] ID = { 0x1, 0x20 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 32)
            {
                byte[] ID = { 0x1, 0x21 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 33)
            {
                byte[] ID = { 0x1, 0x22 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 34)
            {
                byte[] ID = { 0x1, 0x23 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 35)
            {
                byte[] ID = { 0x1, 0x24 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 36)
            {
                byte[] ID = { 0x1, 0x25 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 37)
            {
                byte[] ID = { 0x1, 0x26 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox4.SelectedIndex == 38)
            {
                byte[] ID = { 0x1, 0x27 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x822604AC, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x0));
            if (comboBox5.SelectedIndex == 0)
            {
                byte[] ID = { 0x1, 0x0 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 1)
            {
                byte[] ID = { 0x1, 0x1 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 2)
            {
                byte[] ID = { 0x1, 0x2 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 3)
            {
                byte[] ID = { 0x1, 0x3 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 4)
            {
                byte[] ID = { 0x1, 0x4 };
                XRPC.SetMemory(ResolvePointer, ID);
            }

            else if (comboBox5.SelectedIndex == 5)
            {
                byte[] ID = { 0x1, 0x5 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 6)
            {
                byte[] ID = { 0x1, 0x6 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 7)
            {
                byte[] ID = { 0x1, 0x7 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 8)
            {
                byte[] ID = { 0x1, 0x8 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 9)
            {
                byte[] ID = { 0x1, 0x9 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 10)
            {
                byte[] ID = { 0x1, 0xA };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 11)
            {
                byte[] ID = { 0x1, 0xB };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 12)
            {
                byte[] ID = { 0x1, 0xC };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 13)
            {
                byte[] ID = { 0x1, 0xD };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 14)
            {
                byte[] ID = { 0x1, 0xE };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 15)
            {
                byte[] ID = { 0x1, 0xF };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 16)
            {
                byte[] ID = { 0x1, 0x10 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 17)
            {
                byte[] ID = { 0x1, 0x11 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 18)
            {
                byte[] ID = { 0x1, 0x12 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 19)
            {
                byte[] ID = { 0x1, 0x13 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 20)
            {
                byte[] ID = { 0x1, 0x14 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 21)
            {
                byte[] ID = { 0x1, 0x15 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 22)
            {
                byte[] ID = { 0x1, 0x17 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 23)
            {
                byte[] ID = { 0x1, 0x18 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 24)
            {
                byte[] ID = { 0x1, 0x19 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 25)
            {
                byte[] ID = { 0x1, 0x1A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 26)
            {
                byte[] ID = { 0x1, 0x1B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 27)
            {
                byte[] ID = { 0x1, 0x1C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 28)
            {
                byte[] ID = { 0x1, 0x1D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 29)
            {
                byte[] ID = { 0x1, 0x1E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 30)
            {
                byte[] ID = { 0x1, 0x1F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 31)
            {
                byte[] ID = { 0x1, 0x20 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 32)
            {
                byte[] ID = { 0x1, 0x21 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 33)
            {
                byte[] ID = { 0x1, 0x22 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 34)
            {
                byte[] ID = { 0x1, 0x23 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 35)
            {
                byte[] ID = { 0x1, 0x24 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 36)
            {
                byte[] ID = { 0x1, 0x25 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 37)
            {
                byte[] ID = { 0x1, 0x26 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox5.SelectedIndex == 38)
            {
                byte[] ID = { 0x1, 0x27 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                byte[] HP = {0x38, 0xC0, 0x03, 0x84};
                XRPC.SetMemory(0x82B8140C, HP);
            }

            else
            {
                byte[] HP = {0x7C, 0xE6, 0x07, 0x34};
                XRPC.SetMemory(0x82B8140C, HP);
            }

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                byte[] Melee = {0xD1, 0x9F, 0x33, 0x30};
                XRPC.SetMemory(0x82C15384, Melee);
            }

            else
            {
                byte[] Melee = {0xD1, 0x1F, 0x33, 0x30};
                XRPC.SetMemory(0x82C15384, Melee);
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                byte[] Skills1 = {0x3D, 0x20, 0x99, 0x00};
                byte[] Skills2 = {0x3D, 0x00, 0x99, 0x00};
                XRPC.SetMemory(0x82AFDE30, Skills1);
                XRPC.SetMemory(0x82AFE41C, Skills1);
                XRPC.SetMemory(0x82AFE21C, Skills2);
            }

            else
            {
                byte[] Skills1 = {0x81, 0x3F, 0x04, 0xF0};
                byte[] Skills2 = {0x7D, 0x09, 0x50, 0x50};
                byte[] Skills3 = {0x7D, 0x2B, 0x50, 0x50};
                XRPC.SetMemory(0x82AFDE30, Skills1);
                XRPC.SetMemory(0x82AFE21C, Skills2);
                XRPC.SetMemory(0x82AFE41C, Skills3);
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                byte[] Timer = {0x60, 0x00, 0x00, 0x00};
                XRPC.SetMemory(0x824E0AA4, Timer);
            }

            else
            {
                byte[] Timer = {0xD0, 0x1F, 0x48, 0x18};
                XRPC.SetMemory(0x824E0AA4, Timer);
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            byte[] ItemBranch = XRPC.GetMemory(0x830ADF38, 4);
            Array.Reverse(ItemBranch);
            uint ResolveAmmoBranch = BitConverter.ToUInt32(ItemBranch, 0);

            if (ResolveAmmoBranch == 0x4B1B251C)
            {
                checkBox5.Checked = false;
            }

            else
            {

            }

            if (checkBox5.Checked)
            {
                byte[] Branch = {0x4B, 0x1B, 0x26, 0x68};
                byte[] AmmoCodeCave = {0x39, 0x20, 0x00, 0xFF, 0x7D, 0x2A, 0x1B, 0x2E, 0x48, 0xE4, 0xD9, 0x94};
                XRPC.SetMemory(0x82260464, AmmoCodeCave);
                XRPC.SetMemory(0x830ADDFC, Branch);
            }

            else
            {
                byte[] Branch = {0x7D, 0x2A, 0x1A, 0x2E};
                XRPC.SetMemory(0x830ADDFC, Branch);
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
            {
                byte[] WeaponPointer = XRPC.GetMemory(0x8226049C, 4);
                Array.Reverse(WeaponPointer);
                uint ResolvePointerFirstStep = ((BitConverter.ToUInt32(WeaponPointer, 0) - 0x1C));
                byte[] ResolvePointerSecondStep = BitConverter.GetBytes(ResolvePointerFirstStep);
                Array.Reverse(ResolvePointerSecondStep);
                XRPC.SetMemory(0x8226049C, ResolvePointerSecondStep);
                byte[] WeaponPointer2 = XRPC.GetMemory(0x822604A0, 4);
                Array.Reverse(WeaponPointer2);
                uint ResolvePointerFirstStep2 = ((BitConverter.ToUInt32(WeaponPointer2, 0) - 0x1C));
                byte[] ResolvePointerSecondStep2 = BitConverter.GetBytes(ResolvePointerFirstStep2);
                Array.Reverse(ResolvePointerSecondStep2);
                XRPC.SetMemory(0x822604A0, ResolvePointerSecondStep2);
                byte[] WeaponPointer3 = XRPC.GetMemory(0x822604A4, 4);
                Array.Reverse(WeaponPointer3);
                uint ResolvePointerFirstStep3 = ((BitConverter.ToUInt32(WeaponPointer3, 0) - 0x1C));
                byte[] ResolvePointerSecondStep3 = BitConverter.GetBytes(ResolvePointerFirstStep3);
                Array.Reverse(ResolvePointerSecondStep3);
                XRPC.SetMemory(0x822604A4, ResolvePointerSecondStep3);
                byte[] WeaponPointer4 = XRPC.GetMemory(0x822604A8, 4);
                Array.Reverse(WeaponPointer4);
                uint ResolvePointerFirstStep4 = ((BitConverter.ToUInt32(WeaponPointer4, 0) - 0x1C));
                byte[] ResolvePointerSecondStep4 = BitConverter.GetBytes(ResolvePointerFirstStep4);
                Array.Reverse(ResolvePointerSecondStep4);
                XRPC.SetMemory(0x822604A8, ResolvePointerSecondStep4);
                byte[] WeaponPointer5 = XRPC.GetMemory(0x822604AC, 4);
                Array.Reverse(WeaponPointer5);
                uint ResolvePointerFirstStep5 = ((BitConverter.ToUInt32(WeaponPointer5, 0) - 0x1C));
                byte[] ResolvePointerSecondStep5 = BitConverter.GetBytes(ResolvePointerFirstStep5);
                Array.Reverse(ResolvePointerSecondStep5);
                XRPC.SetMemory(0x822604AC, ResolvePointerSecondStep5);
            }

            else
            {

            }

        }
    }
}
