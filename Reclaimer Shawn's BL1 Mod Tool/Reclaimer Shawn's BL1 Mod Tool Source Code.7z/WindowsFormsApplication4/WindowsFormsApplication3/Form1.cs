﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using XDevkitPlusPlus;
using XRPCLib;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        XRPC XRPC = new XRPC();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            XRPC.Connect();
            if (XRPC.activeConnection == true)
            {
                MessageBox.Show("Connection Successful!");
            }

            else
            {
                MessageBox.Show("Connection Failed!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) You have the choice between an Insta-Kill (that makes everyone in your area including you drop dead immediately) and an Invincibility, but not both. \n2) To properly use the Infinite Skill Points cheat, enable it whenever you get in-game and disable it after you go to the main menu. Otherwise, you won't be able to load saves. \n3) The Level modifier codes make you whatever Level you select. If you rejoin the game without this code on and you had a Level above 69, you will become Level 69. Selecting Level 2 billion results in the player being unable to fire vehicle weapons. Any Levels above 69 also boost vehicle health accordingly. \n4) It's likely this tool will allow you to modify the saves of people on LIVE. Be careful with this.");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                byte[] Money = {0x3C, 0x60, 0x7F, 0xFF};
                XRPC.SetMemory(0x82C682A0, Money);
            }

            else
            {
                byte[] Money = {0x80, 0x63, 0x02, 0xA4};
                XRPC.SetMemory(0x82C682A0, Money);
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                byte[] SkillPoints = {0x39, 0x60, 0x00, 0xFF};
                XRPC.SetMemory(0x82355418, SkillPoints);
            }

            else
            {
                byte[] SkillPoints = {0x81, 0x7D, 0x00, 0x00};
                XRPC.SetMemory(0x82355418, SkillPoints);
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                byte[] SkillCooldown = {0x90, 0x03, 0x00, 0x68};
                XRPC.SetMemory(0x82B0BDE0, SkillCooldown);
            }

            else
            {
                byte[] SkillCooldown = {0xC3, 0xE3, 0x00, 0x68};
                XRPC.SetMemory(0x82B0BDE0, SkillCooldown);
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                byte[] JumpToGunCodeCave = {0x48, 0x8A, 0xC3, 0x98};
                byte[] JumpToGrenadeCodeCave = {0x48, 0x93, 0xF2, 0xF4};
                byte[] GunCodeCave = {0xC0, 0x09, 0x00, 0x68, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x3F, 0xE0, 0x44, 0xB4, 0x93, 0xE9, 0x00, 0x68, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x4B, 0x75, 0x3C, 0x50};
                byte[] GrenadeCodeCave = {0xC0, 0x03, 0x00, 0x68, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x3F, 0xE0, 0x41, 0x10, 0x93, 0xE3, 0x00, 0x68, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x4B, 0x6C, 0x0C, 0xF4};
                XRPC.SetMemory(0x8344BDCC, GunCodeCave);
                XRPC.SetMemory(0x8344BDEC, GrenadeCodeCave);
                XRPC.SetMemory(0x82B9FA34, JumpToGunCodeCave);
                XRPC.SetMemory(0x82B0CAF8, JumpToGrenadeCodeCave);
            }

            else
            {
                byte[] JumpToGunCodeCave = {0xC0, 0x09, 0x00, 0x68};
                byte[] JumpToGrenadeCodeCave = {0xC0, 0x03, 0x00, 0x68};
                XRPC.SetMemory(0x82B9FA34, JumpToGunCodeCave);
                XRPC.SetMemory(0x82B0CAF8, JumpToGrenadeCodeCave);
            }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                byte[] EnemyHP = {0xC0, 0x0A, 0x00, 0x68};
                byte[] YourHP = {0xC0, 0x2B, 0x00, 0x68};
                XRPC.SetMemory(0x8268DDB8, EnemyHP);
                XRPC.SetMemory(0x8268D988, YourHP);
            }

            else if (comboBox2.SelectedIndex == 1)
            {
                byte[] EnemyHP = {0x90, 0x0A, 0x00, 0x68};
                byte[] YourHP = {0xC0, 0x2B, 0x00, 0x68};
                XRPC.SetMemory(0x8268DDB8, EnemyHP);
                XRPC.SetMemory(0x8268D988, YourHP);
            }

            else if (comboBox2.SelectedIndex == 2)
            {
                byte[] EnemyHP = {0xC0, 0x0A, 0x00, 0x68};
                byte[] YourHP = {0x60, 0x00, 0x00, 0x00};
                XRPC.SetMemory(0x8268DDB8, EnemyHP);
                XRPC.SetMemory(0x8268D988, YourHP);
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
            {
                byte[] JumpToCodeCave = {0x48, 0x93, 0x88, 0xF0};
                byte[] CodeCave = {0xC3, 0xEB, 0x00, 0x68, 0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x3F, 0xE0, 0x43, 0xFA, 0x93, 0xEB, 0x00, 0x68, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x4B, 0x6C, 0x76, 0xF8};
                XRPC.SetMemory(0x8344BE10, CodeCave);
                XRPC.SetMemory(0x82B13520, JumpToCodeCave);
            }

            else
            {
                byte[] JumpToCodeCave = {0xC3, 0xEB, 0x00, 0x68};
                XRPC.SetMemory(0x82B13520, JumpToCodeCave);
            }
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked)
            {
                byte[] NOP = {0x60, 0x00, 0x00, 0x00};
                XRPC.SetMemory(0x82BF8078, NOP);
                XRPC.SetMemory(0x82BF7FB4, NOP);
                XRPC.SetMemory(0x82BF7FBC, NOP);
            }

            else
            {
                byte[] Branch1 = {0x4B, 0xEE, 0x96, 0xE1};
                byte[] Branch2 = {0x48, 0x3C, 0x13, 0xCD};
                byte[] Branch3 = {0x4B, 0xEE, 0x91, 0xE5};
                XRPC.SetMemory(0x82BF8078, Branch1);
                XRPC.SetMemory(0x82BF7FB4, Branch2);
                XRPC.SetMemory(0x82BF7FBC, Branch3);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                byte[] BranchToCave = { 0x80, 0xEB, 0x02, 0x84 };
                XRPC.SetMemory(0x82B0D1FC, BranchToCave);
            }

            else if (comboBox1.SelectedIndex == 1)
            {
                byte[] BranchToCave = { 0x48, 0x93, 0xEB, 0xC0 };
                byte[] CodeCave = { 0x3C, 0xE0, 0x00, 0x00, 0x60, 0xE7, 0x00, 0x45, 0x90, 0xEB, 0x02, 0x84, 0x4B, 0x6C, 0x14, 0x38 };
                XRPC.SetMemory(0x8344BDBC, CodeCave);
                XRPC.SetMemory(0x82B0D1FC, BranchToCave);
            }

            else if (comboBox1.SelectedIndex == 2)
            {
                byte[] BranchToCave = { 0x48, 0x93, 0xEB, 0xC0 };
                byte[] CodeCave = { 0x3C, 0xE0, 0x00, 0x00, 0x60, 0xE7, 0x00, 0x64, 0x90, 0xEB, 0x02, 0x84, 0x4B, 0x6C, 0x14, 0x38 };
                XRPC.SetMemory(0x8344BDBC, CodeCave);
                XRPC.SetMemory(0x82B0D1FC, BranchToCave);
            }

            else if (comboBox1.SelectedIndex == 3)
            {
                byte[] BranchToCave = { 0x48, 0x93, 0xEB, 0xC0 };
                byte[] CodeCave = { 0x3C, 0xE0, 0x7F, 0xFF, 0x60, 0xE7, 0xFF, 0xFF, 0x90, 0xEB, 0x02, 0x84, 0x4B, 0x6C, 0x14, 0x38 };
                XRPC.SetMemory(0x8344BDBC, CodeCave);
                XRPC.SetMemory(0x82B0D1FC, BranchToCave);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Credits for the tool go to: \nAbove all else, God and his Son Jesus Christ. \nReclaimer Shawn for most of the tool. \nC0dycode of Shadowevil's modding Discord and Ry of Borderlands: Community Hangout for helping me patch out the sanity check.");
        }
        }
    }
