﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using XDevkitPlusPlus;
using XRPCLib;

namespace WindowsFormsApplication8
{
    public partial class Form1 : Form
    {
        XRPC XRPC = new XRPC();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            XRPC.Connect();
            if (XRPC.activeConnection == true)
            {
                MessageBox.Show("Connection Successful!");
            }

            else
            {
                MessageBox.Show("Connection Failed!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) To properly use the gun modifier, first check the Activate box. Then, select what weapons you want from the dropdown box. Finally, go and change both weapons in the menu screen to any other weapon and you'll be given the weapons of your choice to start out with. \n2) Invincibility only applies to you and your initial three party members, not any other friendly characters. \n3) I suggest only turning insta-kill on whenever you need to kill an enemy. This is because insta-kill can make mission progression impossible and lead to friendly characters dying, causing you to fail the mission. It may even prevent some enemies from spawning.");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                byte[] XP = {0x3D, 0x40, 0x7F, 0xFF};
                XRPC.SetMemory(0x83224588, XP);
            }

            else
            {
                byte[] XP = {0x81, 0x44, 0x00, 0x04};
                XRPC.SetMemory(0x83224588, XP);
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                byte[] Ammo = {0x39, 0x00, 0x00, 0xFF};
                XRPC.SetMemory(0x82980A94, Ammo);
            }

            else
            {
                byte[] Ammo = {0x7D, 0x28, 0x50, 0x38};
                XRPC.SetMemory(0x82980A94, Ammo);
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                byte[] Ability = {0xD0, 0x03, 0x00, 0x20};
                XRPC.SetMemory(0x826C6D34, Ability);
            }

            else
            {
                byte[] Ability = {0xD1, 0x43, 0x00, 0x20};
                XRPC.SetMemory(0x826C6D34, Ability);
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                byte[] CodeCavePart1 = { 0x3D, 0x60 };
                byte[] CodeCavePart2 = { 0x61, 0x6B };
                byte[] PrimaryGunCodeCave = { 0x91, 0x64, 0x00, 0x78, 0x48, 0x5D, 0x5E, 0xF4 };
                byte[] SecondaryGunCodeCave = { 0x91, 0x64, 0x00, 0x7C, 0x48, 0x5D, 0x5E, 0xE4 };
                byte[] PrimaryGunBranch = { 0x4B, 0xA2, 0xA1, 0x04 };
                byte[] SecondaryGunBranch = { 0x4B, 0xA2, 0xA1, 0x14 };
                XRPC.SetMemory(0x82000A80, CodeCavePart1);
                XRPC.SetMemory(0x82000A84, CodeCavePart2);
                XRPC.SetMemory(0x82000A88, PrimaryGunCodeCave);
                XRPC.SetMemory(0x825D697C, PrimaryGunBranch);
                XRPC.SetMemory(0x82000AA0, CodeCavePart1);
                XRPC.SetMemory(0x82000AA4, CodeCavePart2);
                XRPC.SetMemory(0x82000AA8, SecondaryGunCodeCave);
                XRPC.SetMemory(0x825D698C, SecondaryGunBranch);
            }

            else
            {
                byte[] PrimaryGunBranch = {0x91, 0x64, 0x00, 0x78};
                byte[] SecondaryGunBranch = {0x91, 0x64, 0x00, 0x7C};
                XRPC.SetMemory(0x825D697C, PrimaryGunBranch);
                XRPC.SetMemory(0x825D698C, SecondaryGunBranch);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                byte[] FirstPartGunID = {0xE8, 0xC4};
                byte[] SecondPartGunID = {0x03, 0x86};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 1)
            {
                byte[] FirstPartGunID = {0xE5, 0x38};
                byte[] SecondPartGunID = {0x90, 0x74};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 2)
            {
                byte[] FirstPartGunID = {0xB3, 0x8F};
                byte[] SecondPartGunID = {0x5A, 0x31};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 3)
            {
                byte[] FirstPartGunID = {0x42, 0x4C};
                byte[] SecondPartGunID = {0x4B, 0x04};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 4)
            {
                byte[] FirstPartGunID = {0x85, 0x17};
                byte[] SecondPartGunID = {0xC7, 0xDF};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 5)
            {
                byte[] FirstPartGunID = {0xFA, 0x8F};
                byte[] SecondPartGunID = {0x37, 0x71};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 6)
            {
                byte[] FirstPartGunID = {0x66, 0x32};
                byte[] SecondPartGunID = {0x91, 0xD5};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 7)
            {
                byte[] FirstPartGunID = {0xAB, 0x7B};
                byte[] SecondPartGunID = {0x07, 0xB6};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 8)
            {
                byte[] FirstPartGunID = {0x9F, 0xAD};
                byte[] SecondPartGunID = {0x01, 0x52};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 9)
            {
                byte[] FirstPartGunID = {0xBC, 0xD9};
                byte[] SecondPartGunID = {0xE0, 0x8C};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 10)
            {
                byte[] FirstPartGunID = {0x6C, 0x41};
                byte[] SecondPartGunID = {0xAD, 0xC6};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 11)
            {
                byte[] FirstPartGunID = {0x61, 0x0B};
                byte[] SecondPartGunID = {0x33, 0x44};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 12)
            {
                byte[] FirstPartGunID = {0x64, 0xEB};
                byte[] SecondPartGunID = {0xA2, 0xD2};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 13)
            {
                byte[] FirstPartGunID = {0x81, 0xCB};
                byte[] SecondPartGunID = {0x18, 0x84};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 14)
            {
                byte[] FirstPartGunID = {0xED, 0xB3};
                byte[] SecondPartGunID = {0x9A, 0x14};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 15)
            {
                byte[] FirstPartGunID = {0x60, 0xC9};
                byte[] SecondPartGunID = {0x59, 0x73};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 16)
            {
                byte[] FirstPartGunID = {0x99, 0x44};
                byte[] SecondPartGunID = {0x02, 0xDD};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 17)
            {
                byte[] FirstPartGunID = {0xF8, 0x60};
                byte[] SecondPartGunID = {0xAC, 0x8F};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 18)
            {
                byte[] FirstPartGunID = {0x1D, 0xD2};
                byte[] SecondPartGunID = {0xA3, 0xE6};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 19)
            {
                byte[] FirstPartGunID = {0x2E, 0xFD};
                byte[] SecondPartGunID = {0x38, 0x6B};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 20)
            {
                byte[] FirstPartGunID = {0xD9, 0x17};
                byte[] SecondPartGunID = {0xDF, 0x8D};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 21)
            {
                byte[] FirstPartGunID = {0x17, 0xEB};
                byte[] SecondPartGunID = {0xF4, 0xFF};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 22)
            {
                byte[] FirstPartGunID = {0xEA, 0x9B};
                byte[] SecondPartGunID = {0x99, 0x2A};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 23)
            {
                byte[] FirstPartGunID = {0x00, 0x53};
                byte[] SecondPartGunID = {0x73, 0xC7};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 24)
            {
                byte[] FirstPartGunID = {0x7B, 0x62};
                byte[] SecondPartGunID = {0x00, 0xE7};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 25)
            {
                byte[] FirstPartGunID = {0x33, 0x81};
                byte[] SecondPartGunID = {0xDC, 0x3F};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 26)
            {
                byte[] FirstPartGunID = {0xE4, 0xC5};
                byte[] SecondPartGunID = {0x81, 0xC9};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 27)
            {
                byte[] FirstPartGunID = {0x72, 0xFE};
                byte[] SecondPartGunID = {0x3A, 0x15};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 28)
            {
                byte[] FirstPartGunID = {0x53, 0xF6};
                byte[] SecondPartGunID = {0x25, 0x05};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 29)
            {
                byte[] FirstPartGunID = {0x08, 0x93};
                byte[] SecondPartGunID = {0xDF, 0xC4};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 30)
            {
                byte[] FirstPartGunID = {0x04, 0xEB};
                byte[] SecondPartGunID = {0x74, 0x5E};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 31)
            {
                byte[] FirstPartGunID = {0xD7, 0x3D};
                byte[] SecondPartGunID = {0xDC, 0x8F};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 32)
            {
                byte[] FirstPartGunID = {0xEE, 0xFD};
                byte[] SecondPartGunID = {0x92, 0x2D};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 33)
            {
                byte[] FirstPartGunID = {0x44, 0xC9};
                byte[] SecondPartGunID = {0xB3, 0xEA};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 34)
            {
                byte[] FirstPartGunID = {0xC6, 0x00};
                byte[] SecondPartGunID = {0x30, 0x01};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 35)
            {
                byte[] FirstPartGunID = {0xBE, 0x22};
                byte[] SecondPartGunID = {0x54, 0xC0};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 36)
            {
                byte[] FirstPartGunID = {0x90, 0x0D};
                byte[] SecondPartGunID = {0x55, 0x40};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 37)
            {
                byte[] FirstPartGunID = {0x3D, 0xCE};
                byte[] SecondPartGunID = {0x3C, 0x8C};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 38)
            {
                byte[] FirstPartGunID = {0xC6, 0x9E};
                byte[] SecondPartGunID = {0xEE, 0x3B};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }

            else if (comboBox1.SelectedIndex == 39)
            {
                byte[] FirstPartGunID = {0x3F, 0xFE};
                byte[] SecondPartGunID = {0xDF, 0x33};
                XRPC.SetMemory(0x82000A82, FirstPartGunID);
                XRPC.SetMemory(0x82000A86, SecondPartGunID);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                byte[] FirstPartGunID = { 0xE8, 0xC4 };
                byte[] SecondPartGunID = { 0x03, 0x86 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 1)
            {
                byte[] FirstPartGunID = { 0xE5, 0x38 };
                byte[] SecondPartGunID = { 0x90, 0x74 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 2)
            {
                byte[] FirstPartGunID = { 0xB3, 0x8F };
                byte[] SecondPartGunID = { 0x5A, 0x31 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 3)
            {
                byte[] FirstPartGunID = { 0x42, 0x4C };
                byte[] SecondPartGunID = { 0x4B, 0x04 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 4)
            {
                byte[] FirstPartGunID = { 0x85, 0x17 };
                byte[] SecondPartGunID = { 0xC7, 0xDF };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 5)
            {
                byte[] FirstPartGunID = { 0xFA, 0x8F };
                byte[] SecondPartGunID = { 0x37, 0x71 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 6)
            {
                byte[] FirstPartGunID = { 0x66, 0x32 };
                byte[] SecondPartGunID = { 0x91, 0xD5 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 7)
            {
                byte[] FirstPartGunID = { 0xAB, 0x7B };
                byte[] SecondPartGunID = { 0x07, 0xB6 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 8)
            {
                byte[] FirstPartGunID = { 0x9F, 0xAD };
                byte[] SecondPartGunID = { 0x01, 0x52 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 9)
            {
                byte[] FirstPartGunID = { 0xBC, 0xD9 };
                byte[] SecondPartGunID = { 0xE0, 0x8C };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 10)
            {
                byte[] FirstPartGunID = { 0x6C, 0x41 };
                byte[] SecondPartGunID = { 0xAD, 0xC6 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 11)
            {
                byte[] FirstPartGunID = { 0x61, 0x0B };
                byte[] SecondPartGunID = { 0x33, 0x44 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 12)
            {
                byte[] FirstPartGunID = { 0x64, 0xEB };
                byte[] SecondPartGunID = { 0xA2, 0xD2 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 13)
            {
                byte[] FirstPartGunID = { 0x81, 0xCB };
                byte[] SecondPartGunID = { 0x18, 0x84 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 14)
            {
                byte[] FirstPartGunID = { 0xED, 0xB3 };
                byte[] SecondPartGunID = { 0x9A, 0x14 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 15)
            {
                byte[] FirstPartGunID = { 0x60, 0xC9 };
                byte[] SecondPartGunID = { 0x59, 0x73 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 16)
            {
                byte[] FirstPartGunID = { 0x99, 0x44 };
                byte[] SecondPartGunID = { 0x02, 0xDD };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 17)
            {
                byte[] FirstPartGunID = { 0xF8, 0x60 };
                byte[] SecondPartGunID = { 0xAC, 0x8F };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 18)
            {
                byte[] FirstPartGunID = { 0x1D, 0xD2 };
                byte[] SecondPartGunID = { 0xA3, 0xE6 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 19)
            {
                byte[] FirstPartGunID = { 0x2E, 0xFD };
                byte[] SecondPartGunID = { 0x38, 0x6B };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 20)
            {
                byte[] FirstPartGunID = { 0xD9, 0x17 };
                byte[] SecondPartGunID = { 0xDF, 0x8D };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 21)
            {
                byte[] FirstPartGunID = { 0x17, 0xEB };
                byte[] SecondPartGunID = { 0xF4, 0xFF };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 22)
            {
                byte[] FirstPartGunID = { 0xEA, 0x9B };
                byte[] SecondPartGunID = { 0x99, 0x2A };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 23)
            {
                byte[] FirstPartGunID = { 0x00, 0x53 };
                byte[] SecondPartGunID = { 0x73, 0xC7 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 24)
            {
                byte[] FirstPartGunID = { 0x7B, 0x62 };
                byte[] SecondPartGunID = { 0x00, 0xE7 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 25)
            {
                byte[] FirstPartGunID = { 0x33, 0x81 };
                byte[] SecondPartGunID = { 0xDC, 0x3F };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 26)
            {
                byte[] FirstPartGunID = { 0xE4, 0xC5 };
                byte[] SecondPartGunID = { 0x81, 0xC9 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 27)
            {
                byte[] FirstPartGunID = { 0x72, 0xFE };
                byte[] SecondPartGunID = { 0x3A, 0x15 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 28)
            {
                byte[] FirstPartGunID = { 0x53, 0xF6 };
                byte[] SecondPartGunID = { 0x25, 0x05 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 29)
            {
                byte[] FirstPartGunID = { 0x08, 0x93 };
                byte[] SecondPartGunID = { 0xDF, 0xC4 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 30)
            {
                byte[] FirstPartGunID = { 0x04, 0xEB };
                byte[] SecondPartGunID = { 0x74, 0x5E };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 31)
            {
                byte[] FirstPartGunID = { 0xD7, 0x3D };
                byte[] SecondPartGunID = { 0xDC, 0x8F };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 32)
            {
                byte[] FirstPartGunID = { 0xEE, 0xFD };
                byte[] SecondPartGunID = { 0x92, 0x2D };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 33)
            {
                byte[] FirstPartGunID = { 0x44, 0xC9 };
                byte[] SecondPartGunID = { 0xB3, 0xEA };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 34)
            {
                byte[] FirstPartGunID = { 0xC6, 0x00 };
                byte[] SecondPartGunID = { 0x30, 0x01 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 35)
            {
                byte[] FirstPartGunID = { 0xBE, 0x22 };
                byte[] SecondPartGunID = { 0x54, 0xC0 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 36)
            {
                byte[] FirstPartGunID = { 0x90, 0x0D };
                byte[] SecondPartGunID = { 0x55, 0x40 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 37)
            {
                byte[] FirstPartGunID = { 0x3D, 0xCE };
                byte[] SecondPartGunID = { 0x3C, 0x8C };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 38)
            {
                byte[] FirstPartGunID = { 0xC6, 0x9E };
                byte[] SecondPartGunID = { 0xEE, 0x3B };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }

            else if (comboBox2.SelectedIndex == 39)
            {
                byte[] FirstPartGunID = { 0x3F, 0xFE };
                byte[] SecondPartGunID = { 0xDF, 0x33 };
                XRPC.SetMemory(0x82000AA2, FirstPartGunID);
                XRPC.SetMemory(0x82000AA6, SecondPartGunID);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex == 0)
            {
                byte[] Branch = {0x90, 0xFE, 0x00, 0x94};
                XRPC.SetMemory(0x832C8CE0, Branch);
            }

            else if (comboBox3.SelectedIndex == 1)
            {
                byte[] HealthCodeCave = {0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x83, 0xFE, 0x00, 0xA4, 0x2C, 0x1F, 0x00, 0x87, 0x40, 0x82, 0x00, 0x10, 0x38, 0xE0, 0x00, 0x87, 0x90, 0xFE, 0x00, 0x94, 0x48, 0x00, 0x00, 0x20, 0x2C, 0x1F, 0x00, 0xAF, 0x40, 0x82, 0x00, 0x10, 0x38, 0xE0, 0x00, 0xAF, 0x90, 0xFE, 0x00, 0x94, 0x48, 0x00, 0x00, 0x0C, 0x60, 0x00, 0x00, 0x00, 0x90, 0xFE, 0x00, 0x94, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x49, 0x27, 0x51, 0xA0};
                byte[] Branch = {0x4A, 0xD8, 0xAE, 0x20};
                XRPC.SetMemory(0x82053B00, HealthCodeCave);
                XRPC.SetMemory(0x832C8CE0, Branch);
            }

            else if (comboBox3.SelectedIndex == 2)
            {
                byte[] HealthCodeCave = {0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x83, 0xFE, 0x00, 0xA4, 0x2C, 0x1F, 0x00, 0x87, 0x40, 0x82, 0x00, 0x10, 0x60, 0x00, 0x00, 0x00, 0x90, 0xFE, 0x00, 0x94, 0x48, 0x00, 0x00, 0x20, 0x2C, 0x1F, 0x00, 0xAF, 0x40, 0x82, 0x00, 0x10, 0x60, 0x00, 0x00, 0x00, 0x90, 0xFE, 0x00, 0x94, 0x48, 0x00, 0x00, 0x0C, 0x38, 0xE0, 0x00, 0x01, 0x90, 0xFE, 0x00, 0x94, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x49, 0x27, 0x51, 0xA0};
                byte[] Branch = {0x4A, 0xD8, 0xAE, 0x20};
                XRPC.SetMemory(0x82053B00, HealthCodeCave);
                XRPC.SetMemory(0x832C8CE0, Branch);
            }

            else if (comboBox3.SelectedIndex == 3)
            {
                byte[] HealthCodeCave = {0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xE1, 0x00, 0x08, 0x83, 0xFE, 0x00, 0xA4, 0x2C, 0x1F, 0x00, 0x87, 0x40, 0x82, 0x00, 0x10, 0x38, 0xE0, 0x00, 0x87, 0x90, 0xFE, 0x00, 0x94, 0x48, 0x00, 0x00, 0x20, 0x2C, 0x1F, 0x00, 0xAF, 0x40, 0x82, 0x00, 0x10, 0x38, 0xE0, 0x00, 0xAF, 0x90, 0xFE, 0x00, 0x94, 0x48, 0x00, 0x00, 0x0C, 0x38, 0xE0, 0x00, 0x01, 0x90, 0xFE, 0x00, 0x94, 0xBB, 0xE1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x49, 0x27, 0x51, 0xA0};
                byte[] Branch = {0x4A, 0xD8, 0xAE, 0x20};
                XRPC.SetMemory(0x82053B00, HealthCodeCave);
                XRPC.SetMemory(0x832C8CE0, Branch);
            }
        }
    }
}
