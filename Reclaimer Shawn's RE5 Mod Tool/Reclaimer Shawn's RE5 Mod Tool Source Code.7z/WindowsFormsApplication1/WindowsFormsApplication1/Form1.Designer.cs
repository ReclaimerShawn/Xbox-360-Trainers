﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 242);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(269, 27);
            this.button1.TabIndex = 0;
            this.button1.Text = "Connect";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 19);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(92, 17);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "Infinite Money";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(6, 42);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(140, 17);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "Infinite Exchange Points";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(6, 65);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(75, 17);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "Infinite HP";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(290, 242);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(271, 27);
            this.button2.TabIndex = 4;
            this.button2.Text = "Enable Tool";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(6, 88);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(89, 17);
            this.checkBox4.TabIndex = 5;
            this.checkBox4.Text = "Infinite Ammo";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Nothing",
            "Hand-to-hand",
            "Knife (Chris)",
            "M92F (HG)",
            "VZ61 (MG)",
            "Ithaca M37 (SG)",
            "S75 (RIF)",
            "Hand grenade",
            "Incendiary grenade",
            "Flash grenade",
            "SIG 556 (MG)",
            "Proximity Bomb",
            "S&W M29 (MAG)",
            "Grenade launcher",
            "Rocket launcher",
            "Knife (Sheva)",
            "Longbow",
            "H&K P8 (HG)",
            "SIG P226 (HG)",
            "(dummy_wp12)",
            "H&K MP5 (MG)",
            "(dummy_wp14)",
            "Gatling gun",
            "M3 (SG)",
            "Jail Breaker (SG)",
            "(dummy_wp18)",
            "Hydra (SG)",
            "L Hawk (MAG)",
            "S&2 M500 (MAG)",
            "H&K PSG-1 (RIF)",
            "AK-74 (MG)",
            "M93R (HG)",
            "Px4 (HG)",
            "Dragunsov SVD (RIF)",
            "Flamethower",
            "Stun rod",
            "Knife (Wesker)",
            "Knife (Jill)",
            "G. launcher (EXP)",
            "G. launcher (ACD)",
            "G. launcher (ICE)",
            "(dummy_wp28)",
            "Samurai Edge (HG)",
            "(dummy_wp2a)",
            "(dummy_wp2b)",
            "(dummy_wp2c) (Gun turret)",
            "(dummy_wp2d) (PKM Light Mac)",
            "(dummy_wp2e) (Minigun)",
            "Gun turret",
            "Latern",
            "(dummy_wp31)",
            "(dummy_wp32) (bullet sound)",
            "(dummy_wp33)",
            "L.T.D",
            "RPG-7 NVS",
            "Egg (Rotten)",
            "Hand-to-hand",
            "(dummy_wp38) (Rocket launcher)",
            "G. launcher (FLM)",
            "G. launcher (FLS)",
            "G. launcher (ELC)",
            "Egg (White)",
            "Egg (Brown)",
            "Egg (Gold)",
            "(dummy_wp3f) (L.T.D effect)",
            "(dummy_wp40) (launch an explosive)",
            "(dummy_wp41) (launch an acid)",
            "(dummy_wp42) (launch a nitrogen)",
            "(dummy_wp43)",
            "(dummy_wp44) (launch a rocket)",
            "(dummy_wp45)",
            "(dummy_wp46)",
            "(dummy_wp47)",
            "(dummy_wp48)",
            "(dummy_wp49)",
            "(dummy_wp4a)",
            "(dummy_wp4b) (launcher a rocket)",
            "(dummy_wp4c) (launcher a rocket)",
            "(dummy_wp4d) (launcher a flame)",
            "(dummy_wp4e) (launcher a flash)",
            "(dummy_wp4f) (launcher a electric)",
            "Adze",
            "Stickle",
            "Bow gun",
            "Shovel",
            "Dynamite",
            "Machete",
            "Shotgun",
            "Grenade launcher",
            "Giant axe",
            "Steel pipe",
            "Bottle",
            "Chainsaw",
            "(dummy_wp5c) (Molotov cocktail)",
            "Gatling gun",
            "Torch",
            "Spear",
            "Wooden shield",
            "Metal shield",
            "Bow",
            "Shield",
            "Morring star",
            "Stun rod",
            "Knife",
            "Handgun",
            "Rocket Launcher",
            "Adze",
            "Machine gun",
            "Rifle",
            "Molotov cocktail",
            "Hand grenade",
            "Flash grenade",
            "Spear",
            "Chair",
            "Pickaxe",
            "Club",
            "Wrench",
            "Bomb",
            "Megaphone",
            "Machine gun",
            "dummy_wp77) (axe w/fire)",
            "(dummy_wp78) (rock)",
            "(dummy_wp79) (fog)",
            "(dummy_wp7a) (gasoline tank)",
            "(dummy_wp7b)",
            "(dummy_wp7c)",
            "(dummy_wp7d)",
            "(dummy_wp7e)",
            "(dummy_wp7f)",
            "(dummy_wp80) (explosive arrow)",
            "(dummy_wp80) (fire arrow)",
            "(dummy_wp82)",
            "(dummy_wp83) (launch a rocket)",
            "(dummy_wp84)",
            "(dummy_wp85)",
            "(dummy_wp86)",
            "(dummy_wp87)",
            "(dummy_wp88) (rocket launcher)",
            "(dummy_wp89) (Wesker´s Samurai Edge)",
            "(dummy_wp8a) (rocket stopped)",
            "(dummy_wp8b)",
            "(dummy_wp8c) (Uroboros)",
            "(dummy_wp8d)",
            "(dummy_wp8e)",
            "(dummy_wp8f)",
            "Handgun ammo",
            "Machine gun ammo",
            "Shotgun shells",
            "Rifle ammo",
            "(dummy)",
            "Explosives rounds",
            "Acid rounds",
            "Nitrogen rounds",
            "Magnum ammo",
            "Rocket",
            "Arrow",
            "(dummy)",
            "(dummy)",
            "Flame rounds",
            "Flash rounds",
            "Electric rounds",
            "RPG round",
            "Herb (green)",
            "Herb (red)",
            "Herb (X)",
            "First aid spray",
            "Herb (Green)",
            "Herb (Red)",
            "Herb (G+G)",
            "Herb (G+G+G)",
            "Herb (G+R)",
            "Herb (G+X)",
            "Herb (G+R+X)",
            "Melee vest",
            "Bulletproof vest"});
            this.comboBox1.Location = new System.Drawing.Point(6, 23);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(549, 21);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.SelectionChangeCommitted += new System.EventHandler(this.comboBox1_SelectionChangeCommitted);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Location = new System.Drawing.Point(6, 102);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 108);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Basic Hacks";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Location = new System.Drawing.Point(0, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(561, 84);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Item Editor";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(419, 50);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(136, 23);
            this.button6.TabIndex = 12;
            this.button6.Text = "Remove Gun Mods";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(275, 50);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(138, 23);
            this.button5.TabIndex = 11;
            this.button5.Text = "Damage Mod";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(152, 50);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(117, 23);
            this.button4.TabIndex = 10;
            this.button4.Text = "Rapid Fire";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(6, 50);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(140, 23);
            this.button3.TabIndex = 9;
            this.button3.Text = "Infinite Ammo";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(290, 213);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(271, 23);
            this.button7.TabIndex = 9;
            this.button7.Text = "How to Use";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(6, 213);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(269, 23);
            this.button8.TabIndex = 10;
            this.button8.Text = "About";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox5);
            this.groupBox3.Controls.Add(this.comboBox3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.comboBox4);
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Controls.Add(this.checkBox5);
            this.groupBox3.Location = new System.Drawing.Point(213, 102);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(348, 108);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Character Editor";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Normal",
            "Alternate"});
            this.comboBox5.Location = new System.Drawing.Point(221, 71);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 21);
            this.comboBox5.TabIndex = 12;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Chris",
            "Sheva",
            "Jill",
            "Wesker",
            "Josh",
            "Irving",
            "Excella (DLC)",
            "Barry (DLC)",
            "Rebecca (DLC)"});
            this.comboBox3.Location = new System.Drawing.Point(62, 71);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 11;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Sheva";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Chris";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(256, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Jill Skin";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(98, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Character";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Normal",
            "Alternate"});
            this.comboBox4.Location = new System.Drawing.Point(221, 46);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 3;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Chris",
            "Sheva",
            "Jill",
            "Wesker",
            "Josh",
            "Irving",
            "Excella (DLC)",
            "Barry (DLC)",
            "Rebecca (DLC)"});
            this.comboBox2.Location = new System.Drawing.Point(62, 46);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 1;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(3, 16);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(65, 17);
            this.checkBox5.TabIndex = 0;
            this.checkBox5.Text = "Activate";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 271);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Reclaimer Shawn\'s RE5 Mod Tool";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

