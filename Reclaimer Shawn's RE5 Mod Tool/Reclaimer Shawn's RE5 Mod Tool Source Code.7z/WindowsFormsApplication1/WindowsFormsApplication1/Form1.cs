﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using XDevkitPlusPlus;
using XRPCLib;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        XRPC XRPC = new XRPC();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XRPC.Connect();
            if (XRPC.activeConnection == true)
            {
                MessageBox.Show("Connection Successful!");
            }

            else
            {
                MessageBox.Show("Connection Failed!");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                byte[] Money = {0x3D, 0x60, 0x7F, 0xFF};
                XRPC.SetMemory(0x828007C8, Money);
            }

            else
            {
                byte[] Money = {0x7D, 0x64, 0x58, 0x50};
                XRPC.SetMemory(0x828007C8, Money);
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                byte[] Exchange = {0x3D, 0x60, 0x7F, 0xFF};
                XRPC.SetMemory(0x82800818, Exchange);
            }

            else
            {
                byte[] Exchange = {0x7D, 0x64, 0x58, 0x50};
                XRPC.SetMemory(0x82800818, Exchange);
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                byte[] HP = {0x38, 0xC0, 0x03, 0xE8};
                XRPC.SetMemory(0x8269A8C4, HP);
            }

            else
            {
                byte[] HP = {0x7C, 0xE6, 0x07, 0x34};
                XRPC.SetMemory(0x8269A8C4, HP);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            byte[] Enable = {0x94, 0x21, 0xFF, 0x80, 0xBC, 0x61, 0x00, 0x08, 0x91, 0x44, 0x00, 0x08, 0x3D, 0x40, 0x82, 0x00, 0x61, 0x4A, 0x05, 0x04, 0x90, 0x8A, 0x00, 0x00, 0xB8, 0x61, 0x00, 0x08, 0x38, 0x21, 0x00, 0x80, 0x48, 0x76, 0x64, 0xA0, 0x94, 0x21, 0xFF, 0x80, 0xBC, 0x61, 0x00, 0x08, 0x93, 0xB8, 0x00, 0x08, 0x3D, 0x40, 0x82, 0x00, 0x61, 0x4A, 0x05, 0x04, 0x93, 0x0A, 0x00, 0x00, 0xB8, 0x61, 0x00, 0x08, 0x38, 0x21, 0x00, 0x80, 0x48, 0x30, 0x91, 0xDC, 0x94, 0x21, 0xFF, 0x80, 0xBC, 0x61, 0x00, 0x08, 0x93, 0xF2, 0x00, 0x08, 0x3D, 0x40, 0x82, 0x00, 0x61, 0x4A, 0x05, 0x04, 0x92, 0x4A, 0x00, 0x00, 0xB8, 0x61, 0x00, 0x08, 0x38, 0x21, 0x00, 0x80, 0x48, 0x30, 0x83, 0xFC};
            byte[] GunAmmo = {0x4B, 0x89, 0x9B, 0x44};
            byte[] GrenadeAmmo = {0x4B, 0xCF, 0x6E, 0x08};
            byte[] HerbAmmo = {0x4B, 0xCF, 0x7B, 0xE8};
            XRPC.SetMemory(0x82000498, Enable);
            XRPC.SetMemory(0x82766954, GunAmmo);
            XRPC.SetMemory(0x823096B4, GrenadeAmmo);
            XRPC.SetMemory(0x823088F8, HerbAmmo);
            byte[] CharacterCave = {0x80, 0xAB, 0x00, 0x08, 0x2C, 0x05, 0x00, 0x00, 0x40, 0x82, 0x00, 0x08, 0x38, 0xA0, 0x00, 0x00, 0x2C, 0x05, 0x00, 0x01, 0x40, 0x82, 0x00, 0x08, 0x38, 0xA0, 0x00, 0x00, 0x48, 0x04, 0x94, 0x34, 0xA1, 0x5D, 0x00, 0x0A, 0x2C, 0x0A, 0x00, 0x00, 0x40, 0x82, 0x00, 0x08, 0x39, 0x40, 0x00, 0x00, 0x2C, 0x0A, 0x00, 0x01, 0x40, 0x82, 0x00, 0x08, 0x39, 0x40, 0x00, 0x00, 0x48, 0x10, 0x68, 0x34, 0x81, 0x27, 0x00, 0x08, 0x2C, 0x09, 0x00, 0x00, 0x40, 0x82, 0x00, 0x08, 0x39, 0x20, 0x00, 0x00, 0x2C, 0x09, 0x00, 0x01, 0x40, 0x82, 0x00, 0x08, 0x39, 0x20, 0x00, 0x00, 0x48, 0x04, 0xBB, 0xC8};
            XRPC.SetMemory(0x822048EC, CharacterCave);
            byte[] JillCave = {0x94, 0x21, 0xFF, 0xF0, 0xBF, 0xC1, 0x00, 0x08, 0x3F, 0xC0, 0x06, 0xEC, 0x63, 0xDE, 0x6E, 0xC0, 0x7C, 0x1E, 0xF8, 0x00, 0x40, 0x82, 0x00, 0x18, 0x83, 0xFF, 0x00, 0x18, 0x2C, 0x1F, 0x00, 0x02, 0x40, 0x82, 0x00, 0x20, 0x38, 0xA0, 0x00, 0x00, 0x48, 0x00, 0x00, 0x1C, 0x83, 0xFF, 0x00, 0x18, 0x2C, 0x1F, 0x00, 0x02, 0x40, 0x82, 0x00, 0x0C, 0x38, 0xA0, 0x00, 0x00, 0x48, 0x00, 0x00, 0x08, 0x38, 0xA0, 0x00, 0x00, 0xBB, 0xC1, 0x00, 0x08, 0x38, 0x21, 0x00, 0x10, 0x48, 0x5A, 0x4C, 0x2C};
            XRPC.SetMemory(0x8220489C, JillCave);
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                byte[] NOP = {0x60, 0x00, 0x00, 0x00};
                XRPC.SetMemory(0x820004A0, NOP);
                XRPC.SetMemory(0x820004C4, NOP);
                XRPC.SetMemory(0x820004E8, NOP);
            }

            else
            {
                byte[] GunAmmo = {0x91, 0x44, 0x00, 0x08};
                byte[] GrenadeAmmo = {0x93, 0xB8, 0x00, 0x08};
                byte[] HerbAmmo = {0x93, 0xF2, 0x00, 0x08};
                XRPC.SetMemory(0x820004A0, GunAmmo);
                XRPC.SetMemory(0x820004C4, GrenadeAmmo);
                XRPC.SetMemory(0x820004E8, HerbAmmo);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To properly use the tool, click Connect and then click Enable Tool. This allows all of the cheats in the tool to work properly. \n1) If you want to directly mod your weapon and change it, go to a place without enemies and shoot the gun you want to mod once. Then you can change that gun to whatever you want. \n2) To properly use the Character Modifier, click 'Activate' and then select your character and skin (skins only work with Jill). Then select a chapter and enter it and you'll have the characters of your choice. If the 'Activate' button is on and nothing is selected, it should default both players to Chris. Fair warning: Irving crashes the game on Melee, Wesker crashes the game if the H&K P8 isn't equipped, and the character modifier crashes outside of Campaign mode. To avoid this crash, uncheck the 'Activate' box whenever going to another game mode. Characters with the DLC mark will only work if you place the DLC archive files into the nativeXenon folder of RE5. Otherwise, the game will crash upon using them. \n3) Infinite Grenades only works if you have two or more grenades of the type you're using. Otherwise, you'll run out.");
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x82000504, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x6));
            if (comboBox1.SelectedIndex == 0)
            {
                byte[] ID = {0x0, 0x0};
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                byte[] ID = {0x1, 0x0};
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                byte[] ID = {0x1, 0x1};
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                byte[] ID = {0x1, 0x2};
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                byte[] ID = {0x1, 0x3};
                XRPC.SetMemory(ResolvePointer, ID);
            }

            else if (comboBox1.SelectedIndex == 5)
            {
                byte[] ID = { 0x1, 0x4 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 6)
            {
                byte[] ID = { 0x1, 0x5 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 7)
            {
                byte[] ID = { 0x1, 0x6 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 8)
            {
                byte[] ID = { 0x1, 0x7 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 9)
            {
                byte[] ID = { 0x1, 0x8 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 10)
            {
                byte[] ID = { 0x1, 0x9 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 11)
            {
                byte[] ID = { 0x1, 0xA };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 12)
            {
                byte[] ID = { 0x1, 0xB };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 13)
            {
                byte[] ID = { 0x1, 0xC };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 14)
            {
                byte[] ID = { 0x1, 0xD };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 15)
            {
                byte[] ID = { 0x1, 0xE };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 16)
            {
                byte[] ID = { 0x1, 0xF };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 17)
            {
                byte[] ID = { 0x1, 0x10 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 18)
            {
                byte[] ID = { 0x1, 0x11 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 19)
            {
                byte[] ID = { 0x1, 0x12 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 20)
            {
                byte[] ID = { 0x1, 0x13 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 21)
            {
                byte[] ID = { 0x1, 0x14 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 22)
            {
                byte[] ID = { 0x1, 0x15 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 23)
            {
                byte[] ID = { 0x1, 0x16 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 24)
            {
                byte[] ID = { 0x1, 0x17 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 25)
            {
                byte[] ID = { 0x1, 0x18 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 26)
            {
                byte[] ID = { 0x1, 0x19 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 27)
            {
                byte[] ID = { 0x1, 0x1A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 28)
            {
                byte[] ID = { 0x1, 0x1B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 29)
            {
                byte[] ID = { 0x1, 0x1C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 30)
            {
                byte[] ID = { 0x1, 0x1D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 31)
            {
                byte[] ID = { 0x1, 0x1E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 32)
            {
                byte[] ID = { 0x1, 0x1F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 33)
            {
                byte[] ID = { 0x1, 0x20 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 34)
            {
                byte[] ID = { 0x1, 0x21 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 35)
            {
                byte[] ID = { 0x1, 0x22 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 36)
            {
                byte[] ID = { 0x1, 0x23 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 37)
            {
                byte[] ID = { 0x1, 0x24 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 38)
            {
                byte[] ID = { 0x1, 0x25 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 39)
            {
                byte[] ID = { 0x1, 0x26 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 40)
            {
                byte[] ID = { 0x1, 0x27 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 41)
            {
                byte[] ID = { 0x1, 0x28 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 42)
            {
                byte[] ID = { 0x1, 0x29 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 43)
            {
                byte[] ID = { 0x1, 0x2A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 44)
            {
                byte[] ID = { 0x1, 0x2B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 45)
            {
                byte[] ID = { 0x1, 0x2C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 46)
            {
                byte[] ID = { 0x1, 0x2D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 47)
            {
                byte[] ID = { 0x1, 0x2E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 48)
            {
                byte[] ID = { 0x1, 0x2F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 49)
            {
                byte[] ID = { 0x1, 0x30 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 50)
            {
                byte[] ID = { 0x1, 0x31 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 51)
            {
                byte[] ID = { 0x1, 0x32 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 52)
            {
                byte[] ID = { 0x1, 0x33 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 53)
            {
                byte[] ID = { 0x1, 0x34 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 54)
            {
                byte[] ID = { 0x1, 0x35 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 55)
            {
                byte[] ID = { 0x1, 0x36 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 56)
            {
                byte[] ID = { 0x1, 0x37 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 57)
            {
                byte[] ID = { 0x1, 0x38 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 58)
            {
                byte[] ID = { 0x1, 0x39 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 59)
            {
                byte[] ID = { 0x1, 0x3A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 60)
            {
                byte[] ID = { 0x1, 0x3B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 61)
            {
                byte[] ID = { 0x1, 0x3C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 62)
            {
                byte[] ID = { 0x1, 0x3D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 63)
            {
                byte[] ID = { 0x1, 0x3E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 64)
            {
                byte[] ID = { 0x1, 0x3F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 65)
            {
                byte[] ID = { 0x1, 0x40 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 66)
            {
                byte[] ID = { 0x1, 0x41 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 67)
            {
                byte[] ID = { 0x1, 0x42 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 68)
            {
                byte[] ID = { 0x1, 0x43 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 69)
            {
                byte[] ID = { 0x1, 0x44 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 70)
            {
                byte[] ID = { 0x1, 0x45 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 71)
            {
                byte[] ID = { 0x1, 0x46 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 72)
            {
                byte[] ID = { 0x1, 0x47 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 73)
            {
                byte[] ID = { 0x1, 0x48 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 74)
            {
                byte[] ID = { 0x1, 0x49 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 75)
            {
                byte[] ID = { 0x1, 0x4A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 76)
            {
                byte[] ID = { 0x1, 0x4B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 77)
            {
                byte[] ID = { 0x1, 0x4C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 78)
            {
                byte[] ID = { 0x1, 0x4D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 79)
            {
                byte[] ID = { 0x1, 0x4E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 80)
            {
                byte[] ID = { 0x1, 0x4F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 81)
            {
                byte[] ID = { 0x1, 0x50 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 82)
            {
                byte[] ID = { 0x1, 0x51 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 83)
            {
                byte[] ID = { 0x1, 0x52 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 84)
            {
                byte[] ID = { 0x1, 0x53 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 85)
            {
                byte[] ID = { 0x1, 0x54 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 86)
            {
                byte[] ID = { 0x1, 0x55 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 87)
            {
                byte[] ID = { 0x1, 0x56 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 88)
            {
                byte[] ID = { 0x1, 0x57 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 89)
            {
                byte[] ID = { 0x1, 0x58 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 90)
            {
                byte[] ID = { 0x1, 0x59 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 91)
            {
                byte[] ID = { 0x1, 0x5A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 92)
            {
                byte[] ID = { 0x1, 0x5B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 93)
            {
                byte[] ID = { 0x1, 0x5C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 94)
            {
                byte[] ID = { 0x1, 0x5D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 95)
            {
                byte[] ID = { 0x1, 0x5E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 96)
            {
                byte[] ID = { 0x1, 0x5F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 97)
            {
                byte[] ID = { 0x1, 0x60 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 98)
            {
                byte[] ID = { 0x1, 0x61 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 99)
            {
                byte[] ID = { 0x1, 0x62 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 100)
            {
                byte[] ID = { 0x1, 0x63 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 101)
            {
                byte[] ID = { 0x1, 0x64 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 102)
            {
                byte[] ID = { 0x1, 0x65 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 103)
            {
                byte[] ID = { 0x1, 0x66 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 104)
            {
                byte[] ID = { 0x1, 0x67 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 105)
            {
                byte[] ID = { 0x1, 0x68 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 106)
            {
                byte[] ID = { 0x1, 0x69 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 107)
            {
                byte[] ID = { 0x1, 0x6A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 108)
            {
                byte[] ID = { 0x1, 0x6B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 109)
            {
                byte[] ID = { 0x1, 0x6C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 110)
            {
                byte[] ID = { 0x1, 0x6D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 111)
            {
                byte[] ID = { 0x1, 0x6E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 112)
            {
                byte[] ID = { 0x1, 0x6F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 113)
            {
                byte[] ID = { 0x1, 0x70 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 114)
            {
                byte[] ID = { 0x1, 0x71 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 115)
            {
                byte[] ID = { 0x1, 0x72 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 116)
            {
                byte[] ID = { 0x1, 0x73 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 117)
            {
                byte[] ID = { 0x1, 0x74 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 118)
            {
                byte[] ID = { 0x1, 0x75 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 119)
            {
                byte[] ID = { 0x1, 0x76 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 120)
            {
                byte[] ID = { 0x1, 0x77 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 121)
            {
                byte[] ID = { 0x1, 0x78 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 122)
            {
                byte[] ID = { 0x1, 0x79 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 123)
            {
                byte[] ID = { 0x1, 0x7A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 124)
            {
                byte[] ID = { 0x1, 0x7B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 125)
            {
                byte[] ID = { 0x1, 0x7C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 126)
            {
                byte[] ID = { 0x1, 0x7D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 127)
            {
                byte[] ID = { 0x1, 0x7E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 128)
            {
                byte[] ID = { 0x1, 0x7F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 129)
            {
                byte[] ID = { 0x1, 0x80 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 130)
            {
                byte[] ID = { 0x1, 0x81 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 131)
            {
                byte[] ID = { 0x1, 0x82 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 132)
            {
                byte[] ID = { 0x1, 0x83 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 133)
            {
                byte[] ID = { 0x1, 0x84 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 134)
            {
                byte[] ID = { 0x1, 0x85 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 135)
            {
                byte[] ID = { 0x1, 0x86 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 136)
            {
                byte[] ID = { 0x1, 0x87 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 137)
            {
                byte[] ID = { 0x1, 0x88 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 138)
            {
                byte[] ID = { 0x1, 0x89 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 139)
            {
                byte[] ID = { 0x1, 0x8A };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 140)
            {
                byte[] ID = { 0x1, 0x8B };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 141)
            {
                byte[] ID = { 0x1, 0x8C };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 142)
            {
                byte[] ID = { 0x1, 0x8D };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 143)
            {
                byte[] ID = { 0x1, 0x8E };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 144)
            {
                byte[] ID = { 0x1, 0x8F };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 145)
            {
                byte[] ID = { 0x2, 0x1 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 146)
            {
                byte[] ID = { 0x2, 0x2 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 147)
            {
                byte[] ID = { 0x2, 0x3 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 148)
            {
                byte[] ID = { 0x2, 0x4 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 149)
            {
                byte[] ID = { 0x2, 0x5 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 150)
            {
                byte[] ID = { 0x2, 0x6 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 151)
            {
                byte[] ID = { 0x2, 0x7 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 152)
            {
                byte[] ID = { 0x2, 0x8 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 153)
            {
                byte[] ID = { 0x2, 0x9 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 154)
            {
                byte[] ID = { 0x2, 0xA };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 155)
            {
                byte[] ID = { 0x2, 0xB };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 156)
            {
                byte[] ID = { 0x2, 0xC };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 157)
            {
                byte[] ID = { 0x2, 0xD };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 158)
            {
                byte[] ID = { 0x2, 0xE };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 159)
            {
                byte[] ID = { 0x2, 0xF };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 160)
            {
                byte[] ID = { 0x2, 0x10 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 161)
            {
                byte[] ID = { 0x2, 0x11 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 162)
            {
                byte[] ID = { 0x3, 0x1 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 163)
            {
                byte[] ID = { 0x3, 0x2 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 164)
            {
                byte[] ID = { 0x3, 0x3 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 165)
            {
                byte[] ID = { 0x3, 0x4 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 166)
            {
                byte[] ID = { 0x3, 0x5 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 167)
            {
                byte[] ID = { 0x3, 0x6 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 168)
            {
                byte[] ID = { 0x3, 0x7 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 169)
            {
                byte[] ID = { 0x3, 0x8 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 170)
            {
                byte[] ID = { 0x3, 0x9 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 171)
            {
                byte[] ID = { 0x3, 0xA };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 172)
            {
                byte[] ID = { 0x3, 0xB };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 173)
            {
                byte[] ID = { 0x6, 0x1 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
            else if (comboBox1.SelectedIndex == 174)
            {
                byte[] ID = { 0x6, 0x6 };
                XRPC.SetMemory(ResolvePointer, ID);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x82000504, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x23));
            byte[] Write = { 0xFE };
            XRPC.SetMemory(ResolvePointer, Write);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x82000504, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x21));
            byte[] Write = { 0xFF };
            XRPC.SetMemory(ResolvePointer, Write);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x82000504, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x20));
            byte[] Write = { 0xFF };
            XRPC.SetMemory(ResolvePointer, Write);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            byte[] WeaponPointer = XRPC.GetMemory(0x82000504, 4);
            Array.Reverse(WeaponPointer);
            uint ResolvePointer = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x23));
            byte[] Write = { 0x00 };
            XRPC.SetMemory(ResolvePointer, Write);
            uint ResolvePointer2 = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x21));
            XRPC.SetMemory(ResolvePointer2, Write);
            uint ResolvePointer3 = ((BitConverter.ToUInt32(WeaponPointer, 0) + 0x20));
            XRPC.SetMemory(ResolvePointer3, Write);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This tool is a tool I'll use for the fun of it. It should work in every game mode. You might even be able to modify people's items online if you're the host of the game. Thank you Lord for giving me the knowledge to make this tool! Thank you MODDED WARFARE and MBRKiNG for the tutorial videos on how to make trainers, too!");
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                byte[] Branch1 = {0x4B, 0xFB, 0x6B, 0xB4};
                byte[] Branch2 = {0x4B, 0xEF, 0x97, 0xB4};
                byte[] Branch3 = {0x4B, 0xFB, 0x44, 0x20};
                byte[] Branch4 = {0x4B, 0xA5, 0xB3, 0x8C};
                XRPC.SetMemory(0x8224DD38, Branch1);
                XRPC.SetMemory(0x8230B158, Branch2);
                XRPC.SetMemory(0x8225050C, Branch3);
                XRPC.SetMemory(0x827A9510, Branch4);
            }

            else
            {
                byte[] Branch1 = {0x80, 0xAB, 0x00, 0x08};
                byte[] Branch2 = {0xA1, 0x5D, 0x00, 0x0A};
                byte[] Branch3 = {0x81, 0x27, 0x00, 0x08};
                byte[] Branch4 = {0x88, 0xA7, 0x00, 0x23};
                XRPC.SetMemory(0x8224DD38, Branch1);
                XRPC.SetMemory(0x8230B158, Branch2);
                XRPC.SetMemory(0x8225050C, Branch3);
                XRPC.SetMemory(0x827A9510, Branch4);
            }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x00};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x00};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x00};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }

            else if (comboBox2.SelectedIndex == 1)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x01};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x01};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x01};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }

            else if (comboBox2.SelectedIndex == 2)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x02};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x02};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x02};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }

            else if (comboBox2.SelectedIndex == 3)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x03};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x03};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x03};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }

            else if (comboBox2.SelectedIndex == 4)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x04};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x04};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x04};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }

            else if (comboBox2.SelectedIndex == 5)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x86};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x86};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x86};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }

            else if (comboBox2.SelectedIndex == 6)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x05};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x05};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x05};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }

            else if (comboBox2.SelectedIndex == 7)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x06};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x06};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x06};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }

            else if (comboBox2.SelectedIndex == 8)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x07};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x07};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x07};
                XRPC.SetMemory(0x822048F8, Char1);
                XRPC.SetMemory(0x82204918, Char2);
                XRPC.SetMemory(0x82204938, Char3);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex == 0)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x00};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x00};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x00};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }

            else if (comboBox3.SelectedIndex == 1)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x01};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x01};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x01};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }

            else if (comboBox3.SelectedIndex == 2)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x02};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x02};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x02};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }

            else if (comboBox3.SelectedIndex == 3)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x03};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x03};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x03};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }

            else if (comboBox3.SelectedIndex == 4)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x04};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x04};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x04};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }

            else if (comboBox3.SelectedIndex == 5)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x86};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x86};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x86};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }

            else if (comboBox3.SelectedIndex == 6)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x05};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x05};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x05};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }

            else if (comboBox3.SelectedIndex == 7)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x06};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x06};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x06};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }

            else if (comboBox3.SelectedIndex == 8)
            {
                byte[] Char1 = {0x38, 0xA0, 0x00, 0x07};
                byte[] Char2 = {0x39, 0x40, 0x00, 0x07};
                byte[] Char3 = {0x39, 0x20, 0x00, 0x07};
                XRPC.SetMemory(0x82204904, Char1);
                XRPC.SetMemory(0x82204924, Char2);
                XRPC.SetMemory(0x82204944, Char3);
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox4.SelectedIndex == 0)
            {
                byte[] Skin = {0x38, 0xA0, 0x00, 0x00};
                XRPC.SetMemory(0x822048C0, Skin);
            }

            else if (comboBox4.SelectedIndex == 1)
            {
                byte[] Skin = {0x38, 0xA0, 0x00, 0x01};
                XRPC.SetMemory(0x822048C0, Skin);
            }
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox5.SelectedIndex == 0)
            {
                byte[] Skin = {0x38, 0xA0, 0x00, 0x00};
                XRPC.SetMemory(0x822048D4, Skin);
            }

            else if (comboBox5.SelectedIndex == 1)
            {
                byte[] Skin = {0x38, 0xA0, 0x00, 0x01};
                XRPC.SetMemory(0x822048D4, Skin);
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
