﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using XDevkitPlusPlus;
using XRPCLib;

namespace WindowsFormsApplication5
{
    public partial class Form1 : Form
    {
        XRPC XRPC = new XRPC();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte[] NOP = {0x60, 0x00, 0x00, 0x00};
            XRPC.SetMemory(0x82E4EFC4, NOP);
            XRPC.SetMemory(0x82E4F014, NOP);
            XRPC.SetMemory(0x82E4F01C, NOP);
            XRPC.SetMemory(0x82E4F030, NOP);
            XRPC.SetMemory(0x82E4F040, NOP);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Credits for the tool go to: \nAbove all else, God and his Son Jesus Christ. \nReclaimer Shawn for most of the tool. \nC0dycode of Shadowevil's modding Discord and Ry of Borderlands: Community Hangout for helping me patch out the sanity check.");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            XRPC.Connect();
            if (XRPC.activeConnection == true)
            {
                MessageBox.Show("Connection Successful!");
            }

            else
            {
                MessageBox.Show("Connection Failed!");
            }
        }
    }
}
