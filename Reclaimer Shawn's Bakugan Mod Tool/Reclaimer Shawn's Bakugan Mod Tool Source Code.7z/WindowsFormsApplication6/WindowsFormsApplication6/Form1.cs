﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using XDevkitPlusPlus;
using XRPCLib;

namespace WindowsFormsApplication6
{
    public partial class Form1 : Form
    {
        XRPC XRPC = new XRPC();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            XRPC.Connect();
            if (XRPC.activeConnection == true)
            {
                MessageBox.Show("Connection Successful!");
            }

            else
            {
                MessageBox.Show("Connection Failed!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To use the tool properly, go to the Bakugan Shop and enable a cheat. \n1) Infinite Money takes effect after buying an item once (you have to have enough money to buy at least one item for this to work). \n2) Max Stat, Max Level, and 32767 G Power takes effect after upgrading the associated stat once. I recommend using Max Stat and 32767 G Power to max out a Bakugan first and then enabling Max Level last to make it max level. \n3) To use the Bakugan Shop Modifier cheat, enable it in the Shop Options first. Then select a Bakugan and Attribute. If you don't, the cheat will default to a Pyrus Dragonoid. Any Bakugan bought from the shop, as well as any Bakugan upgraded, will morph into the Bakugan of choice. Be careful though: if you buy a Pyrus mon but select a Haos Attribute, you'll get a Haos Bakguan deposited in a Pyrus slot. I recommend buying a Bakugan of the same attribute whenever doing this. \n4) After getting out of the shop, disable all of the cheats.");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                byte[] Money1 = {0x3D, 0x00, 0x7F, 0xFF};
                byte[] Money2 = {0x61, 0x08, 0xFF, 0xFF};
                XRPC.SetMemory(0x8237E130, Money1);
                XRPC.SetMemory(0x8237E138, Money2);
            }

            else
            {
                byte[] Money1 = {0x39, 0x2B, 0xFF, 0xFF};
                byte[] Money2 = {0x7D, 0x28, 0xE8, 0x38};
                XRPC.SetMemory(0x8237E130, Money1);
                XRPC.SetMemory(0x8237E138, Money2);
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                byte[] Stat = {0x39, 0x20, 0x00, 0x32};
                XRPC.SetMemory(0x821CC310, Stat);
            }

            else
            {
                byte[] Stat = {0x7D, 0x28, 0x4A, 0x14};
                XRPC.SetMemory(0x821CC310, Stat);
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                byte[] Level = {0x39, 0x60, 0x00, 0x0A};
                XRPC.SetMemory(0x821CC31C, Level);
            }

            else
            {
                byte[] Level = {0x39, 0x6B, 0x00, 0x01};
                XRPC.SetMemory(0x821CC31C, Level);
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                byte[] Power = {0x39, 0x00, 0x7F, 0xFF};
                XRPC.SetMemory(0x821CC334, Power);
            }

            else
            {
                byte[] Power = {0x39, 0x00, 0x7F, 0xFF};
                XRPC.SetMemory(0x821CC334, Power);
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                byte[] CodeCave = {0x38, 0xA0, 0x00, 0x00, 0x38, 0x80, 0x00, 0x00, 0x90, 0xA3, 0x00, 0x04, 0x48, 0x12, 0x53, 0x94};
                byte[] Branch = {0x4B, 0xED, 0xAC, 0x64};
                XRPC.SetMemory(0x820A6EB4, CodeCave);
                XRPC.SetMemory(0x821CC250, Branch);
            }

            else
            {
                byte[] Branch = {0x90, 0xA3, 0x00, 0x04};
                XRPC.SetMemory(0x821CC250, Branch);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                byte[] ID = {0x00};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 1)
            {
                byte[] ID = {0x01};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 2)
            {
                byte[] ID = {0x04};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 3)
            {
                byte[] ID = {0x05};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 4)
            {
                byte[] ID = {0x06};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 5)
            {
                byte[] ID = {0x07};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 6)
            {
                byte[] ID = {0x08};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 7)
            {
                byte[] ID = {0x09};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 8)
            {
                byte[] ID = {0x0A};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 9)
            {
                byte[] ID = {0x0B};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 10)
            {
                byte[] ID = {0x0C};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 11)
            {
                byte[] ID = {0x0D};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 12)
            {
                byte[] ID = {0x0E};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 13)
            {
                byte[] ID = {0x19};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 14)
            {
                byte[] ID = {0x1A};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 15)
            {
                byte[] ID = {0x1B};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 16)
            {
                byte[] ID = {0x1C};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 17)
            {
                byte[] ID = {0x1D};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 18)
            {
                byte[] ID = {0x1E};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 19)
            {
                byte[] ID = {0x27};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 20)
            {
                byte[] ID = {0x28};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 21)
            {
                byte[] ID = {0x29};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 22)
            {
                byte[] ID = {0x2A};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 23)
            {
                byte[] ID = {0x2B};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 24)
            {
                byte[] ID = {0x2C};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 25)
            {
                byte[] ID = {0x2D};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 26)
            {
                byte[] ID = {0x2E};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 27)
            {
                byte[] ID = {0x2F};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 28)
            {
                byte[] ID = {0x30};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 29)
            {
                byte[] ID = {0x31};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 30)
            {
                byte[] ID = {0x32};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 31)
            {
                byte[] ID = {0x34};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 32)
            {
                byte[] ID = {0x38};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 33)
            {
                byte[] ID = {0x3A};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 34)
            {
                byte[] ID = {0x3C};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 35)
            {
                byte[] ID = {0x3D};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 36)
            {
                byte[] ID = {0x3E};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 37)
            {
                byte[] ID = {0x3F};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 38)
            {
                byte[] ID = {0x40};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 39)
            {
                byte[] ID = {0x41};
                XRPC.SetMemory(0x820A6EBB, ID);
            }

            else if (comboBox1.SelectedIndex == 40)
            {
                byte[] ID = {0x42};
                XRPC.SetMemory(0x820A6EBB, ID);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                byte[] ID = {0x00};
                XRPC.SetMemory(0x820A6EB7, ID);
            }

            else if (comboBox2.SelectedIndex == 1)
            {
                byte[] ID = {0x01};
                XRPC.SetMemory(0x820A6EB7, ID);
            }

            else if (comboBox2.SelectedIndex == 2)
            {
                byte[] ID = {0x02};
                XRPC.SetMemory(0x820A6EB7, ID);
            }

            else if (comboBox2.SelectedIndex == 3)
            {
                byte[] ID = {0x03};
                XRPC.SetMemory(0x820A6EB7, ID);
            }

            else if (comboBox2.SelectedIndex == 4)
            {
                byte[] ID = {0x04};
                XRPC.SetMemory(0x820A6EB7, ID);
            }

            else if (comboBox2.SelectedIndex == 5)
            {
                byte[] ID = {0x05};
                XRPC.SetMemory(0x820A6EB7, ID);
            }
        }
    }
}
